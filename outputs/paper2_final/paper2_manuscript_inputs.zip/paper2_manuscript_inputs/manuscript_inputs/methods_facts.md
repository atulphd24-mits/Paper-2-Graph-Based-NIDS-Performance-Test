# Paper 2 methods facts (from the code that ran)

Collected read-only on 2026-10-25. The final run used commits `e800706` (splits, E-GraphSAGE
inductive, seeds 0–9) and `601f92f` (all other parts). `src/`, `scripts/paper2_final.py` and
`configs/` are identical on both commits and on `paper2-final`, so every file cited below is the
code that ran. "Derived" marks a value computed from the code's logic rather than read from an output.

The hyper-parameter table is in `hyperparameters.tex`.

---

## 1. Hyper-parameters (summary; full table in `hyperparameters.tex`)

| Model | Settings | Source |
|---|---|---|
| HistGB | ≤ 300 iterations, learning rate 0.1, `class_weight="balanced"`; defaults: 31 leaves, ≥ 20 samples/leaf, 255 bins, no L2; early stopping automatic (on above 10,000 rows): internal 10% of training rows, log-loss, patience 10 | `scripts/robustness_study.py:68` (`make_model`) |
| Random forest | 200 trees, `min_samples_leaf=2`, `max_features="sqrt"`, `class_weight="balanced_subsample"`; unlimited depth, bootstrap | same |
| MLP | signed log → standard scaling → MLP (128, 64), ReLU, Adam 1e-3, α = 1e-4, batch 512, ≤ 100 epochs, early stopping on internal 10% (patience 8); minority class oversampled with replacement to the majority size | same; `balanced_rows` at `:88` |
| E-GraphSAGE | 2 layers, hidden 128, dropout 0.2, node states start as ones, mean aggregation in both edge directions, classifier on [z_u ‖ z_v]; full batch, Adam 1e-3, weight decay 1e-5, ≤ 300 epochs, inverse-frequency class weights; validation PR-AUC every 5 epochs, patience 30, best state restored; 8 CPU threads | `src/models/egraphsage.py:84`, `:103`; edge features `scripts/egraphsage_study.py:52` |
| k-NN features | k = 20, Euclidean, on the training-fitted flow transform; index, LOF (novelty mode) and scaler from training rows only; training rows leave themselves out | `src/graph/neighborhood_features.py`; `scripts/paper2_final.py:66` (K = 20) |
| Gate | experts = HistGB on flow / flow + neighbourhood / flow + host; router = multiclass HistGB on flow features, 200 iterations, balanced, no early stopping (a rare family can have one training flow, which breaks the internal stratified split) | `src/models/two_branch.py:28`, `:38` |

**Things to state precisely in the text:**
- MLP early stopping draws its internal 10% from the training rows *after* minority oversampling,
  so duplicated minority rows can sit on both sides of that internal split. This affects only
  when training stops, never test data.
- E-GraphSAGE "inductive": test edges never enter the training graph, but at final scoring message
  passing runs on the graph of **all** flows (train, validation, test and purged).
  Transductive: all edges in every phase.
- Best endpoint for the 30-seed runs (validation PR-AUC, mean over seeds 0–9,
  `reports/endpoint_selection.csv`): ToN-IoT IP:port (0.928 vs IP 0.900); CSE-CIC-IDS2018 IP
  (0.992 vs IP:port 0.968).

## 2. Feature sets

- **Behaviour (flow) features:** BigFlow 47, UNSW-NB15 41, CIC-IoT2023 46 (recorded in every
  run's meta `sample_info`). Excluded: flow start/end timestamps, source/destination IP, source
  port, DNS query id, host features and the sampling columns `file_id`, `file_row`,
  `design_weight`, `episode_full` (`scripts/paper2_final.py:149`, `model_features`).
- **Host features, 78** (`src/features/host_causal.py:129`, `CausalHostFeatures`):
  - 3 windows (1 s, 10 s, 60 s) × 3 keys: source host and destination host (9 statistics each),
    source–destination pair (8; "peers" is dropped because it equals destination ports) =
    26 per window.
  - Statistics: flows, distinct peers, distinct destination ports, SYN-only ratio (SYN without
    ACK in client flags), no-reply ratio (0 reply packets), tiny-flow ratio (≤ 2 packets), mean
    log bytes, destination-port entropy, ports/flows ratio.
  - **Window (t − w, t]: the current flow is included.** Flows with the same millisecond count
    only if earlier in stream order (BigFlow: file, then row). Later flows never change a feature.
  - Computed over **all flows of each source in the full data** (ToN-IoT 27,520,260;
    CSE-CIC-IDS2018 20,115,529; `scripts/build_causal_sample.py`, log
    `logs/build_stratified_sample.log`), then attached to the sampled rows. No labels used.
  - **Host features are behaviour statistics, not identities:** IPs are only used as grouping
    keys.
- **Neighbourhood features** (derived count): 3 label-aware + one share per training family
  (benign included) + 3 distances + LOF + 3 × 6 raw-column statistics = 25 + number of classes:
  **35 for ToN-IoT** (10 classes), **40 for CSE-CIC-IDS2018** (15 classes). Raw columns:
  in/out bytes, in packets, max TCP window in, min TTL, longest flow packet
  (`NEIGHBOUR_CONTEXT_COLUMNS`, `scripts/leakage_study.py:64`).

## 3. Working sample and design weights

(`scripts/build_stratified_sample.py`, `src/data/stratified_sample.py:24`)

- **Attack classes:** per (source, class), cap C = 20,000 flows. Classes ≤ 20,000 flows are kept
  whole (weight 1). Otherwise k_e = min(20, s_e) flows are drawn from every full-data episode
  (1-min gap); the remaining quota R = C − Σk_e is filled at random from the rest. If Σk_e > C,
  every episode gets the same reduced share, ⌊C / #episodes⌋, at least 1.
- **Design weight** = 1 / π_e, with π_e = k_e/s_e + (1 − k_e/s_e) · R / N_rest, constant within
  an episode. Benign rows: the v1 sample (about 100k per source); weight = full-data benign count
  / sampled benign count (constant per source; `check_benign_weights_constant` enforces this).
- **Sample sizes** (`data/processed/bigflow_working_sample_strat_causal.parquet`, 860,742 rows):

  | Source | Rows | Attack rows | Benign rows | Families | Σ design weights | Full-data flows |
  |---|---|---|---|---|---|---|
  | ToN-IoT | 250,219 | 149,984 | 100,235 | 9 | 27,520,100 | 27,520,260 |
  | CSE-CIC-IDS2018 | 305,581 | 205,988 | 99,593 | 14 | 20,115,663 | 20,115,529 |
  | BoT-IoT | 113,604 | 61,615 | 51,989 | 4 | 16,934,593 | 16,933,808 |
  | UNSW-NB15 (BigFlow part) | 191,338 | 91,129 | 100,209 | 9 | 2,365,429 | 2,365,424 |
  | UNSW-NB15 original (`unsw_…strat_causal`) | 196,605 | 97,031 | 99,574 | 9 | 2,539,959 | 2,540,047 |
  | CIC-IoT2023 (`ciciot_working_sample`, not stratified) | 639,807 | 539,387 | 100,420 | 33 | class-level prevalence weights | 46,686,579 |

  **Check before writing "the weights sum to the full-data counts":** they agree within 0.005%
  per source, not exactly (ToN-IoT −160, CSE-CIC +134 flows; BoT-IoT is +785). Safe wording:
  "the weights reproduce the full-data flow counts to within 0.005% per source".
- **Training is unweighted**; design weights enter only F1-threshold tuning on validation and
  every reported test metric (`PROTOCOL_FREEZE.md` §7).

## 4. Splits (`src/models/evaluation.py`)

- **Targets 70/15/15** per (source, class). **Realized** shares of the working sample, main
  protocol, 30 seeds (HistGB context runs; train = rows − validation − test − purged):

  | Source | Train | Validation | Test | Purged |
  |---|---|---|---|---|
  | ToN-IoT | 0.608 (0.553–0.655) | 0.155 (0.134–0.188) | 0.144 (0.122–0.175) | 0.093 (0.056–0.169) |
  | CSE-CIC-IDS2018 | 0.600 (0.563–0.624) | 0.145 (0.133–0.158) | 0.151 (0.136–0.175) | 0.105 (0.100–0.109) |

  The purge comes almost entirely out of training: test is never purged, and validation only
  near test units.
- **Episode assignment** (`assign_episodes_constrained`, `:158`): each episode independently to
  train/validation/test with p = 0.70/0.15/0.15. A draw is accepted when every split has ≥ 1
  episode, training ≥ 50% of the class's flows, and validation and test each 10–25%
  (`TRAIN_MIN_SHARE`, `HELD_OUT_SHARE_RANGE`, `:150`). Up to 1,000 draws, else largest-first.
  **Benign** flows are grouped into 30-minute blocks per source and assigned by the same
  procedure. Classes with < 3 episodes in the sample are split by time (70/15/15 chronological);
  because every full-data episode keeps ≥ 1 sampled flow, this equals the full-data episode count.
- **Embargo** (`apply_embargo`, `:485`), E = 5 min, per class:
  - Margins are measured from each held-out unit's **full-data time range** (episode start to
    end), not from its sampled flows.
  - Purged: training flows within 5 min of any validation or test unit of the same class;
    validation flows within 5 min of a test unit of the same class (1 min for
    chronological-fallback classes). Test flows are never purged.
  - Benign 30-min blocks follow the same rule among themselves.
- **IP purge (benign host rule):** a benign *training* flow is purged if its source or
  destination IP appears, as source or destination, in a validation or test **attack** flow of the
  same source dataset that started 0–60 s before it. Only sampled held-out attack flows are
  checked.
- **Random rows:** `train_test_split` 85/15, then 70/15 of the total, stratified by class; no
  embargo (`scripts/leakage_study.py:87`).
- **Chronological reference:** every class split by time 70/15/15, E = 5 min (`:556`).
- **Split validation for the gate** (`split_validation`, `:390`): within each class, validation
  episodes are shuffled and assigned to whichever half has fewer flows (the first two seed the
  halves), so no episode is split. Classes with one validation episode or in the chronological
  fallback are split by time (the earlier half selects, the later half sets thresholds).

## 5. Test subsets and the 500-flow rule (`scripts/paper2_final.py:229`, `test_subsets`)

- A class enters **subset (i)** in a seed if it has **≥ 3 distinct test episodes** among its
  sampled test attack flows (episode mode) **and ≥ 500 training flows**: sampled, unweighted
  training flows of that class *after* the embargo purge (`MIN_TRAIN_FLOWS = 500`, `:70`).
- Classes failing either rule are listed per seed (`dropped_from_cross` in the results) and
  tested only in (iii). Example: CSE-CIC Brute Force-XSS (480 flows in the whole sample) and
  SQL injection (440) can never reach 500 training flows (Table A14).
- (ii) = chronological-fallback classes. (iii) = all test attacks. All subsets share all test
  benign flows and one threshold.

## 6. "Limitation only" sources (quoted)

`PROTOCOL_FREEZE.md` §1, Data table:

> | BigFlow's BoT-IoT and UNSW-NB15 parts | stated limitations only (99.7% attacks; saturated) |

Table 1 confirms BoT-IoT's attack share of 0.997. The freeze file gives no further reason for
"saturated" (BigFlow's UNSW-NB15 part); if the paper needs one, cite the v1 results.

## 7. Gated detector routing

- **Per-seed expert choices were saved:** `results/gated_choices_final_gated.csv` (seeds 0–9)
  and `results/gated_choices_final_hl_gated.csv` (10–29), one row per (source, seed, validation
  version, family). The backing summary is in `manuscript_inputs/gated_routing.csv`.
- **"5 of 9 families": confirmed.** ToN-IoT, split validation: the worst seed by gated FPR is
  seed 23 (FPR 0.287). There, the host-feature expert was chosen for 5 of 9 attack families
  (DDoS, DoS, injection, password, scanning); none used the pooled default.
- **"FPR correlation 0.90": confirmed.** Pearson correlation over 30 seeds between the gated
  detector's test FPR and the flow + host expert's: **0.90** (vs 0.43 with the flow expert).
  Reused validation: 0.80; CSE-CIC-IDS2018: 0.69 (split) and 0.95 (reused), all at FPR ≤ 1.5%.
- Routing rule: a family's expert is the one with the highest unweighted validation TPR at 1% FPR;
  the flow expert is kept unless another is strictly better; families with < 50 validation attack
  flows use the flow expert. Final score = Σ over attack families of the router probability
  (renormalized over attack classes) × that family's expert score, each expert calibrated to
  validation-benign percentiles (`two_branch.py:56`, `:142`).

## 8. Reproducibility

- **Software** (identical in every final-run meta file): Python 3.12.3, NumPy 2.4.6, pandas 3.0.3,
  scikit-learn 1.9.0, SciPy 1.18.0, PyTorch 2.13.0 (CPU only), Numba 0.66.0 (host features).
- **Hardware:** Intel Xeon Silver 4310 (24 cores), 62 GB RAM, no GPU.
- **Run times** (`logs/*_final_*_meta.json`, wall clock per part):

  | Part | Seeds | Hours |
  |---|---|---|
  | Split comparison (BigFlow) | 0–9 | 1.4 |
  | Context, main protocol (HistGB, RF, MLP) | 0–9 | 6.2 |
  | Context, main, HistGB | 10–29 | 4.1 |
  | Context sensitivity (gap 5 / chronological / E = 0) | 0–9 | 2.1 / 2.2 / 2.3 |
  | Gated detector | 0–9 / 10–29 | 2.8 / 5.9 |
  | E-GraphSAGE inductive / transductive (3 endpoints, 2 split protocols) | 0–9 | 29.9 / 25.3 |
  | E-GraphSAGE inductive, best endpoint (ToN-IoT / CSE-CIC) | 10–29 | 3.0 / 2.3 |
  | UNSW-NB15: splits / context / E-GraphSAGE | 0–9 | 0.2 / 0.8 / 15.2 |
  | CIC-IoT2023: splits / context | 0–9 | 0.8 / 6.0 |

  The parts sum to 110.6 h. Two lanes ran in parallel: 80.4 h elapsed (2026-10-16 12:47 to
  2026-10-19 21:12).
- **Repository URL and licence: NOT FOUND.** The repository has no git remote, no LICENSE file,
  and no URL or licence in README.md. Needed for the data and code availability statement:
  the public repository URL (and a release DOI, e.g. Zenodo), the code licence, and the licence
  of each dataset (BigFlow-NIDS v2, DOI 10.17632/nv729tbdgz.2; UNSW-NB15; CIC-IoT2023). Check
  each dataset's licence on its landing page; none is recorded here.
- Per-flow predictions: 500 parquet files, 917 MB (`outputs/paper2_final/predictions/`).
