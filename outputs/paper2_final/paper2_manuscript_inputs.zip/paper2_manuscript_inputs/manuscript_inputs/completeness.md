# Paper 2 final run: completeness

Seeds 0-9 (Phase A, 13 parts) and 10-29 (Phase B, 4 parts). Prediction row ids were compared with independently recomputed splits by `check_phase_a.py` / `check_phase_b.py` (reports in `reports/`); this check confirms that no result or prediction file changed since. Known, expected: UNSW-NB15 chronological timestamp-only has a constant score in all 10 seeds (no detection beyond the training time range).

**Status: COMPLETE**

## Run integrity

| part | meta_status | commit | dirty | seeds | log_end | done_lines | expected_done | seeds_10_29 |
|---|---|---|---|---|---|---|---|---|
| splits | finished | e800706 | False | True | end | 20 | 20 | nan |
| ctx_main | finished | 601f92f | False | True | end | 20 | 20 | nan |
| ctx_gap5 | finished | 601f92f | False | True | end | 20 | 20 | nan |
| ctx_chrono | finished | 601f92f | False | True | end | 20 | 20 | nan |
| ctx_e0 | finished | 601f92f | False | True | end | 20 | 20 | nan |
| gated | finished | 601f92f | False | True | end | 20 | 20 | nan |
| unsw_splits | finished | 601f92f | False | True | end | 10 | 10 | nan |
| unsw_context | finished | 601f92f | False | True | end | 10 | 10 | nan |
| ciciot_splits | finished | 601f92f | False | True | end | 10 | 10 | nan |
| ciciot_context | finished | 601f92f | False | True | end | 10 | 10 | nan |
| egs_ind | finished | e800706 | False | True | end | 40 | 40 | nan |
| egs_tr | finished | 601f92f | False | True | end | 40 | 40 | nan |
| unsw_egs | finished | 601f92f | False | True | end | 20 | 20 | nan |
| hl_ctx_main | finished | 601f92f | False | nan | end | 40 | 40 | True |
| hl_gated | finished | 601f92f | False | nan | end | 40 | 40 | True |
| hl_egs_ind_ToN_IoT | finished | 601f92f | False | nan | end | 20 | 20 | True |
| hl_egs_ind_CSE_CIC_IDS2018 | finished | 601f92f | False | nan | end | 20 | 20 | True |

## Result rows

| part | result_rows | expected_combos | missing | unexpected | duplicated (combo, subset) | subset patterns |
|---|---|---|---|---|---|---|
| splits | 480 | 240 | 0 | 0 | 0 | all,fallback: 80; all,cross-episode,fallback: 80; all: 80 |
| ctx_main | 720 | 240 | 0 | 0 | 0 | all,cross-episode,fallback: 240 |
| ctx_gap5 | 180 | 80 | 0 | 0 | 0 | all,fallback: 60; all,cross-episode,fallback: 20 |
| ctx_chrono | 160 | 80 | 0 | 0 | 0 | all,fallback: 80 |
| ctx_e0 | 240 | 80 | 0 | 0 | 0 | all,cross-episode,fallback: 80 |
| gated | 600 | 200 | 0 | 0 | 0 | all,cross-episode,fallback: 200 |
| unsw_splits | 200 | 120 | 0 | 0 | 0 | all,fallback: 40; all,cross-episode: 40; all: 40 |
| unsw_context | 240 | 120 | 0 | 0 | 0 | all,cross-episode: 120 |
| ciciot_splits | 30 | 30 | 0 | 0 | 0 | all: 30 |
| ciciot_context | 60 | 60 | 0 | 0 | 0 | all: 60 |
| egs_ind | 320 | 160 | 0 | 0 | 0 | all,cross-episode,fallback: 80; all: 80 |
| egs_tr | 240 | 120 | 0 | 0 | 0 | all,cross-episode,fallback: 60; all: 60 |
| unsw_egs | 180 | 120 | 0 | 0 | 0 | all,cross-episode: 60; all: 60 |
| hl_ctx_main | 480 | 160 | 0 | 0 | 0 | all,cross-episode,fallback: 160 |
| hl_gated | 1200 | 400 | 0 | 0 | 0 | all,cross-episode,fallback: 400 |
| hl_egs_ind_ToN_IoT | 120 | 40 | 0 | 0 | 0 | all,cross-episode,fallback: 40 |
| hl_egs_ind_CSE_CIC_IDS2018 | 120 | 40 | 0 | 0 | 0 | all,cross-episode,fallback: 40 |

## Prediction files

| part | expected_files | missing |
|---|---|---|
| splits | 60 | 0 |
| ctx_main | 20 | 0 |
| ctx_gap5 | 20 | 0 |
| ctx_chrono | 20 | 0 |
| ctx_e0 | 20 | 0 |
| gated | 40 | 0 |
| unsw_splits | 30 | 0 |
| unsw_context | 10 | 0 |
| ciciot_splits | 10 | 0 |
| ciciot_context | 10 | 0 |
| egs_ind | 40 | 0 |
| egs_tr | 40 | 0 |
| unsw_egs | 20 | 0 |
| hl_ctx_main | 40 | 0 |
| hl_gated | 80 | 0 |
| hl_egs_ind_ToN_IoT | 20 | 0 |
| hl_egs_ind_CSE_CIC_IDS2018 | 20 | 0 |

## Logs

0 error lines in run logs; 0 result/prediction files modified after the deep checks.

