# Smoke test v2 — main protocol (1-min gap, 5-min embargo), seed 0

Rules (2026-10-14): constrained random episode assignment (>= 1 episode per split, train >= 50%,
validation and test 10-25% of flows; 1000 draws; largest-first fallback, logged); embargo 5 min
train-vs-held-out, validation-vs-test 5 min (1 min for chronological-fallback classes); benign
training flows purged only if they share an IP with a held-out attack flow that started <= 60 s
before them (checked on the sampled flows); families with < 500 training flows or < 3 test
episodes excluded from the cross-episode subset.
Files: `smoke_family_assignment_{bigflow,unsw}.csv`, `smoke_subsets_{bigflow,unsw}.csv`.

## Coverage of test attack flows
| source | cross-episode (i) | fallback (ii) | excluded from (i) |
|---|---|---|---|
| ToN-IoT | 11.0% (515 flows, 10 episodes: Backdoor, DDoS) | 46.2% (DoS, password, xss) | 42.8% (injection, mitm, ransomware, scanning) |
| CSE-CIC-IDS2018 | 3.1% (163 flows, 17 episodes: LOIC-HTTP, Infiltration) | 80.5% (8 classes) | 16.4% (GoldenEye, web attacks, SQL injection) |
| UNSW-NB15 (original) | 70.2% (29 episodes) | 0% | 29.8% (Backdoor, DoS, Recon, Shellcode, Worms) |

## Benign flows removed by the host rule + block buffer
ToN-IoT 21.0%, CSE-CIC-IDS2018 9.5%, UNSW-NB15 10.3% (previous blanket rule: 58%, 26%, 47%).

## Largest-first fallback used
ToN-IoT Backdoor, DDoS; CSE-CIC-IDS2018 LOIC-HTTP, Infiltration. One dominant episode makes the
10-25% test constraint impossible; their test shares are 1% (Backdoor), 10% (DDoS), 1% (LOIC-HTTP), 3% (Infiltration).

## Flags
- < 50 validation flows: CSE-CIC-IDS2018 Brute-Force-Web (40), Brute-Force-XSS (20), SQL injection (14);
  UNSW-NB15 Worms (7). All also have < 500 training flows (excluded from (i)).
- Cross-episode test flows from a single episode: ToN-IoT scanning, CSE-CIC-IDS2018 GoldenEye,
  UNSW-NB15 Reconnaissance (all excluded from (i) by the 3-episode rule).
- Fallback classes now keep validation data (e.g. Hulk 307 validation flows; was 0).
