# Phase 0 — Code audit (read-only)

Date: 2026-10-14. Scope: the code that produced the results in `paper/outline.md` and
`paper2_export/`. No code or results were changed for this audit.

**Summary.** Two places let held-out (validation/test) information influence the features or
representations used in training. Neither uses test **labels**, but both break ground rule 4
as written ("no test information may influence training"):

| # | Where | What leaks | Severity |
|---|---|---|---|
| A | Host features (Q1) | Tumbling windows include **future** flows (up to the window length) and flows of **all splits** | High: affects every "+ host" result |
| B | Neighbourhood context features (Q2) | k-NN distances, LOF and neighbour statistics are computed over **all** rows, incl. val/test | Medium: affects every "+ neighbourhood" result (label-free part only) |
| C | E-GraphSAGE (Q3) | Transductive: val/test edges (features, not labels) are in the message-passing graph during training | Medium: standard for E-GraphSAGE, but must be reported or replaced by the inductive mode |

Thresholds (Q4) and the family-gated detector (Q5) use validation data only; Q5 reuses the same
validation set for expert choice and for the final alert threshold (validation reuse, not test
leakage). Episodes (Q6) are built on the working sample, not on the full data, and the
chronological fallback dominates at the 30-minute gap. No multiple-comparison correction is applied
(Q7).

---

## Q1. Host features — not past-only

`src/graph/host_features.py`, `HostBehaviorFeatures.transform`, lines 109–141:

```python
122  for window_ms in self.windows_ms:
124      data["_window"] = (data[self.time_column] // window_ms).astype(np.int64)
126      views = {
127          f"src{name}": ([self.src_column, "_window"], self.dst_column),
128          f"dst{name}": ([self.dst_column, "_window"], self.src_column),
129          f"pair{name}": ([self.src_column, self.dst_column, "_window"], self.dst_port_column),
133      }
134      for prefix, (keys, peer) in views.items():
135          features = self._group_features(data, keys, prefix, peer)
139          parts.append(data[keys].join(features, on=keys)[features.columns])
```

- Windows are **tumbling (fixed-bin) aggregates**: `time // window_ms` assigns each flow to a
  calendar bin, and the statistics of the whole bin are joined back to every flow in it. A flow at
  the start of a 60-s bin therefore sees up to 60 s of **future** flows; a flow at the end sees up to
  60 s of past flows. They are neither past-only nor centred.
- They are computed over **all flows of the source dataset**, regardless of split:
  `scripts/build_working_sample.py` lines 42–58 (`host_features_for_source`: concatenates all flows
  of the source, line 55; `HostBehaviorFeatures().transform(traffic)`, line 58), and for UNSW-NB15
  `scripts/external_study.py` line 93 (all 2.54M records).
- Consequence: a training flow's host features can contain test-split flows that fall in the same
  bin and the same host, and vice versa. Labels are not used, so this is feature leakage, not label
  leakage. Under the episode split, train and test flows of the same host share bins only at episode
  boundaries, but the future-flow look-ahead applies to every flow.

**Verdict: fix required (Phase 1, item 1).**

## Q2. Neighbourhood (k-NN) features — label part correct, context part transductive

`src/graph/neighborhood_features.py`:

- **Label-aware features** (`label_features`, lines 76–125): the index is built on training rows
  only (`self._knn(X[train_rows], X, exclude_self_rows=position)`, lines 97–99, where `_knn` fits
  `NearestNeighbors` on `reference`, line 57). Validation and test flows get neighbours only from
  training flows. Leave-one-out is applied to training flows (`exclude_self_rows`, lines 60–70).
  ✅ No leakage.
- **Label-free context features** (`context_features`, lines 127–160): the index is built on
  **all** rows (`self._knn(X, X, exclude_self_rows=np.arange(len(X)))`, lines 136–138) and the local
  outlier factor is fitted on all rows (`LocalOutlierFactor(...).fit(X)`, lines 146–148). Distances,
  LOF scores and neighbour mean/std/deviation of training flows therefore depend on validation and
  test flows' feature values (not labels). ❌ Transductive.
- The input space `X` comes from `FlowFeatureTransformer`, fitted on training rows only
  (`fit_transform(sdf, fit_rows=train)`, `scripts/leakage_study.py` lines 325 and 387). ✅

**Verdict: the label-aware part is clean; the context part should be made inductive (index and
LOF fitted on training rows only, val/test queried against them). Not listed in the Phase 1 plan;
I recommend adding it.**

## Q3. E-GraphSAGE — full-batch transductive

`src/models/egraphsage.py`, `train_egraphsage`, lines 103–152:

- The graph contains **every** flow of the 60k-flow subsample: `build_endpoint_graph(sdf, mode)`
  (`scripts/egraphsage_study.py` line 71) creates one edge per flow regardless of split.
- Each epoch runs message passing over all edges, including validation and test edges
  (`model(edge_index, edge_attr, num_nodes)`, line 132); only the loss is restricted to training
  edges (`[train_mask]`, line 132). Validation and test edge **features** therefore shape the node
  embeddings used to classify training edges. Labels of val/test edges are not used.
- Edge-feature scaling is fitted on training rows only (`edge_features`,
  `scripts/egraphsage_study.py` lines 52–54). Early stopping uses validation PR-AUC
  (line 141). ✅
- Same pattern in `scripts/external_study.py` (UNSW-NB15).

**Verdict: transductive, as in the original E-GraphSAGE evaluation. Phase 1, item 2 (inductive
mode) addresses it.**

## Q4. Thresholds — validation only ✅

- `scripts/leakage_study.py`, `operational_metrics`, lines 114–131: the alert thresholds receive
  `scores[val & (y == 0)]` (validation benign only, line 127); the F1 threshold is tuned on
  prevalence-weighted validation rows (`tune_threshold(y[val], scores[val], sample_weight=val_weights)`,
  lines 123–124).
- `src/models/evaluation.py`, `evaluate_detection`, lines 250–300: threshold =
  `np.quantile(val_benign_scores, 1 - fpr)` (line 290), applied to test scores; the FPR reached on
  test is computed as `y_pred[benign].mean()` and stored as `testFPR@1pct` / `testFPR@0.1pct`
  (line 293).
- It is saved in every `*_raw.csv` (per seed) and, as `testFPR@…_mean/_std`, in every
  `*_summary.csv` written through `summarise` (`scripts/leakage_study.py`, extra columns starting
  with `testFPR@`). It is **not** shown in the paper tables or figures.
- Model-internal early stopping (HistGB `early_stopping='auto'`, MLP `early_stopping=True`) holds
  out part of the **training** rows. ✅
- Exception (Part 1 only, pooled shortcut analysis): `fit_score` tunes an unweighted F1 threshold on
  validation (`scripts/leakage_study.py` line 84). Still validation-only. ✅

## Q5. Family-gated detector — validation only ✅ (with validation reuse)

`src/models/two_branch.py`, `FamilyGatedDetector.fit`, lines 66–118:

- Experts are trained on training rows (`fit(X[train_mask], y[train_mask])`, line 86).
- Calibration references are validation benign scores (`benign_reference_[name] = np.sort(scores[y[val_mask] == 0])`,
  lines 88–90).
- The router is trained on training rows (`fit(router_input[train_mask], family[train_mask])`,
  lines 94–96).
- Expert choice per family uses validation TPR at 1% FPR (lines 99–116).
- ⚠️ The **same validation set** is then used in `operational_metrics` to set the final alert
  threshold of the gated score (`scripts/leakage_study.py` lines 398–410 → 123–127). This is
  validation reuse, not test leakage; it can make the gated detector's validation-calibrated
  threshold slightly optimistic. A held-out calibration split would remove it.

## Q6. Episodes — built on the working sample; fallback large at 30 min

- `episode_split` is called on the **working sample**, not the full data: on each source's full
  working sample in Part 3 (`scripts/leakage_study.py` line 251) and on the 60k-flow subsample
  (`source_frame` / `sample(frac=max_rows/len(sdf), random_state=0)`) in Parts 4–5, robustness and
  E-GraphSAGE (`scripts/leakage_study.py` lines 306, 316, 372, 382; `scripts/robustness_study.py`
  lines 110–114, 184, 223; `scripts/egraphsage_study.py` line 78).
- Consequence: gaps are measured between **sampled** flows. Sampling thins the flow sequence, so
  gaps look longer and runs split into more episodes than they would on the full data. Episode
  boundaries therefore depend on the sampling rate.
- Families falling back to the chronological split (fewer than 3 episodes on the 60k subsample,
  seed 0, `robustB_gap_episode_counts.csv`):

| Gap | CSE-CIC-IDS2018 | ToN-IoT |
|---|---|---|
| 1 min | HOIC, LOIC-UDP, Hulk, SlowHTTPTest, Slowloris, FTP-BruteForce, SSH-Bruteforce (7) | none |
| 5 min | the 7 above + Bot (8) | DDoS, DoS, password, xss (4) |
| 30 min | all 14 families (each has ≤ 2 episodes) | Backdoor, DDoS, DoS, injection, mitm, password, ransomware, xss (8 of 9) |

- Share of **test** flows from the chronological fallback (mean ± sd over 10 seeds,
  `robustB_gap_raw.csv`, flow features):

| Gap | CSE-CIC-IDS2018 | ToN-IoT |
|---|---|---|
| 1 min | 0.253 ± 0.043 | 0.000 ± 0.000 |
| 5 min | 0.329 ± 0.053 | 0.199 ± 0.023 |
| 30 min | 0.670 ± 0.002 | 0.456 ± 0.027 |

- **Implication:** at the 30-minute gap the "episode split" is mostly a chronological split
  (67% / 46% of test flows), so the 30-minute sensitivity run tests a different protocol, not
  just a longer gap. The paper currently describes it as an episode-gap sensitivity check; that
  wording should change.

## Q7. Statistical tests currently reported

All use `paired_tests` (`scripts/leakage_study.py` lines 137–157): two-sided Wilcoxon signed-rank
test (`scipy.stats.wilcoxon`, default `zero_method='wilcox'`), paired by seed, on
**TPR@1%FPR** and **weighted PR-AUC**; skipped (NaN) with fewer than 5 seeds or all-zero
differences. **No multiple-comparison correction; no confidence intervals.**

| # | Script (line) | Comparison | Grouping | Seeds | Output |
|---|---|---|---|---|---|
| 1 | `leakage_study.py` Part 4 (354) | {+neigh., +host, +neigh.+host} vs flow, HistGB | per source (4 sources) | 10 | `part4_graph_significance.csv` |
| 2 | `leakage_study.py` Part 5 (432) | gated vs {flow, flow+host, expert mean} | per source (2) | 10 | `part5_two_branch_significance.csv` |
| 3 | `robustness_study.py` A2 (202) | {+neigh., +host, +both} vs flow | per source × {RF, MLP} | 10 | `robustA2_features_models_significance.csv` |
| 4 | `robustness_study.py` B (254) | {+host, +neigh.+host} vs flow, HistGB | per source × gap {1, 5, 30} | 10 | `robustB_gap_significance.csv` |
| 5 | `egraphsage_study.py` (104) | E-GraphSAGE {IP, IP:port, random} vs flow-only HistGB | per source × split | 10 | `egraphsage_significance.csv` |
| 6 | `external_study.py` (329) | {+neigh., +host, +both} vs flow | per dataset × {HistGB, RF, MLP} | 10 | `{unsw,ciciot}_context_significance.csv` |
| 7 | `external_study.py` (333) | E-GraphSAGE {IP, IP:port, random} vs HistGB (UNSW-NB15) | per dataset | 10 | `unsw_context_significance.csv` |

Descriptive only (no test): Part 1 shortcuts (3 seeds), Part 3 split strategies and robustness A1
split comparison (5 seeds; minimum attainable p = 0.0625), external split comparisons.

In total 138 p-values are reported across these files (half on TPR@1%FPR, half on PR-AUC).

---

## Other observations

1. **Git.** The project is **not a git repository**, so ground rules 5 and 8 (branch
   `paper2-final`, commits per phase, commit hash per run) cannot be followed yet. Proposed first
   step of Phase 1: `git init`, a `.gitignore` excluding `data/`, `outputs/`, `.venv/`, `venv/`,
   `*.zip`, then an initial commit of the current code, and the branch `paper2-final`.
2. **Hyper-parameters** are fixed defaults (HistGB 300 iterations, RF 200 trees, MLP (128, 64),
   E-GraphSAGE as in the paper description, k = 20, windows 1/10/60 s). None was tuned on test data.
   k = 20 was chosen in an earlier exploratory script on validation PR-AUC
   (`scripts/improved_graph_detection.py`), on a different sample; it is now fixed.
3. **Prevalence weights** use the test rows' own class counts to re-weight them
   (`prevalence_weights`, `src/models/evaluation.py`); this uses test labels only for evaluation,
   which is legitimate.
4. **Sample reuse across seeds.** The 60k-flow subsample per source is fixed (`random_state=0`);
   seeds vary the split and the model. Seed-to-seed variance therefore does not include sampling
   variance.
5. **Phase 1 scope suggestion.** Fixing Q2 (inductive neighbourhood context) is not in the Phase 1
   plan but has the same kind of effect as Q1; I suggest fixing both and re-running together, so
   the context experiments run once.

Stopped after Phase 0, as instructed.
