# Post-hoc: decomposition of the split gap (claim C4) — DEVIATION

Post-hoc (DEVIATION, decided 2026-10-20 after results were seen): how much of the random-row vs
episode-split gap (claim C4) is family mix, how much is threshold transfer, and how much is left.

From the saved predictions of the split comparison (HistGB, RF, MLP on flow/behaviour features,
seeds 0-9, BigFlow ToN-IoT and CSE-CIC-IDS2018), subset (iii) = all test attacks:

  family mix   (a) pooled: design weights, as in the frozen analysis;
               (b) reweighted: test-attack weights rescaled per family so every split has the
                   full-data family mix (total attack weight unchanged, benign untouched);
               (c) unweighted mean of per-family TPRs.
  threshold    "val": the frozen threshold (99th percentile of validation benign, score > tau);
               "oracle": 99th percentile of the split's own TEST benign scores, so both splits sit
                   at 1% test FPR; this removes threshold transfer.
  F1           weighted F1 with the threshold tuned on weighted validation rows (frozen), and the
               best weighted F1 over all test thresholds (oracle).

Usage: python scripts/posthoc_split_decomposition.py
Writes outputs/paper2_final/stats/posthoc_split_decomposition{,_summary}.csv and
reports/posthoc_split_decomposition.md.

Gap = random rows − episode split, mean over 10 paired seeds, bootstrap 95% CI.

| source | model | metric | random_rows | episodes | gap | gap_ci_low | gap_ci_high | seeds_random_higher |
|---|---|---|---|---|---|---|---|---|
| CSE-CIC-IDS2018 | HistGB | TPR_pooled_val | 0.954 | 0.935 | 0.019 | 0.013 | 0.025 | 10 |
| CSE-CIC-IDS2018 | HistGB | TPR_reweighted_val | 0.954 | 0.957 | -0.003 | -0.010 | 0.003 | 5 |
| CSE-CIC-IDS2018 | HistGB | TPR_unweighted_family_mean_val | 0.951 | 0.952 | -0.002 | -0.009 | 0.006 | 5 |
| CSE-CIC-IDS2018 | HistGB | TPR_pooled_oracle | 0.954 | 0.934 | 0.020 | 0.013 | 0.026 | 10 |
| CSE-CIC-IDS2018 | HistGB | TPR_reweighted_oracle | 0.954 | 0.957 | -0.003 | -0.010 | 0.004 | 5 |
| CSE-CIC-IDS2018 | HistGB | TPR_unweighted_family_mean_oracle | 0.951 | 0.952 | -0.001 | -0.009 | 0.007 | 5 |
| CSE-CIC-IDS2018 | HistGB | FPR_val | 0.010 | 0.011 | -0.002 | -0.003 | -0.000 | 2 |
| CSE-CIC-IDS2018 | HistGB | FPR_oracle | 0.010 | 0.010 | -0.000 | -0.001 | -0.000 | 2 |
| CSE-CIC-IDS2018 | HistGB | F1_pooled_val | 0.971 | 0.957 | 0.014 | 0.010 | 0.018 | 10 |
| CSE-CIC-IDS2018 | HistGB | F1_reweighted_val | 0.971 | 0.970 | 0.001 | -0.004 | 0.005 | 5 |
| CSE-CIC-IDS2018 | HistGB | F1_pooled_oracle | 0.971 | 0.958 | 0.013 | 0.009 | 0.017 | 10 |
| CSE-CIC-IDS2018 | HistGB | F1_reweighted_oracle | 0.971 | 0.972 | -0.000 | -0.004 | 0.004 | 5 |
| CSE-CIC-IDS2018 | MLP | TPR_pooled_val | 0.952 | 0.931 | 0.022 | 0.015 | 0.028 | 10 |
| CSE-CIC-IDS2018 | MLP | TPR_reweighted_val | 0.952 | 0.954 | -0.002 | -0.009 | 0.005 | 5 |
| CSE-CIC-IDS2018 | MLP | TPR_unweighted_family_mean_val | 0.947 | 0.939 | 0.008 | -0.000 | 0.016 | 8 |
| CSE-CIC-IDS2018 | MLP | TPR_pooled_oracle | 0.952 | 0.930 | 0.022 | 0.015 | 0.028 | 10 |
| CSE-CIC-IDS2018 | MLP | TPR_reweighted_oracle | 0.952 | 0.954 | -0.002 | -0.009 | 0.005 | 5 |
| CSE-CIC-IDS2018 | MLP | TPR_unweighted_family_mean_oracle | 0.947 | 0.938 | 0.009 | 0.000 | 0.017 | 8 |
| CSE-CIC-IDS2018 | MLP | FPR_val | 0.010 | 0.011 | -0.001 | -0.002 | 0.000 | 4 |
| CSE-CIC-IDS2018 | MLP | FPR_oracle | 0.010 | 0.010 | 0.000 | 0.000 | 0.000 | 8 |
| CSE-CIC-IDS2018 | MLP | F1_pooled_val | 0.969 | 0.953 | 0.017 | 0.013 | 0.020 | 10 |
| CSE-CIC-IDS2018 | MLP | F1_reweighted_val | 0.969 | 0.966 | 0.003 | -0.001 | 0.007 | 5 |
| CSE-CIC-IDS2018 | MLP | F1_pooled_oracle | 0.970 | 0.955 | 0.015 | 0.011 | 0.020 | 10 |
| CSE-CIC-IDS2018 | MLP | F1_reweighted_oracle | 0.970 | 0.968 | 0.002 | -0.002 | 0.006 | 5 |
| CSE-CIC-IDS2018 | RandomForest | TPR_pooled_val | 0.954 | 0.934 | 0.020 | 0.014 | 0.027 | 10 |
| CSE-CIC-IDS2018 | RandomForest | TPR_reweighted_val | 0.954 | 0.957 | -0.003 | -0.009 | 0.004 | 5 |
| CSE-CIC-IDS2018 | RandomForest | TPR_unweighted_family_mean_val | 0.951 | 0.953 | -0.002 | -0.008 | 0.005 | 5 |
| CSE-CIC-IDS2018 | RandomForest | TPR_pooled_oracle | 0.954 | 0.934 | 0.020 | 0.014 | 0.027 | 10 |
| CSE-CIC-IDS2018 | RandomForest | TPR_reweighted_oracle | 0.954 | 0.957 | -0.003 | -0.009 | 0.004 | 5 |
| CSE-CIC-IDS2018 | RandomForest | TPR_unweighted_family_mean_oracle | 0.951 | 0.953 | -0.002 | -0.008 | 0.005 | 5 |
| CSE-CIC-IDS2018 | RandomForest | FPR_val | 0.011 | 0.011 | 0.000 | -0.001 | 0.001 | 5 |
| CSE-CIC-IDS2018 | RandomForest | FPR_oracle | 0.010 | 0.010 | 0.000 | 0.000 | 0.000 | 8 |
| CSE-CIC-IDS2018 | RandomForest | F1_pooled_val | 0.970 | 0.955 | 0.015 | 0.011 | 0.020 | 10 |
| CSE-CIC-IDS2018 | RandomForest | F1_reweighted_val | 0.970 | 0.964 | 0.006 | 0.002 | 0.011 | 6 |
| CSE-CIC-IDS2018 | RandomForest | F1_pooled_oracle | 0.971 | 0.956 | 0.015 | 0.010 | 0.020 | 10 |
| CSE-CIC-IDS2018 | RandomForest | F1_reweighted_oracle | 0.971 | 0.967 | 0.004 | -0.001 | 0.009 | 5 |
| ToN-IoT | HistGB | TPR_pooled_val | 0.820 | 0.621 | 0.199 | 0.069 | 0.338 | 8 |
| ToN-IoT | HistGB | TPR_reweighted_val | 0.820 | 0.681 | 0.138 | 0.022 | 0.266 | 6 |
| ToN-IoT | HistGB | TPR_unweighted_family_mean_val | 0.836 | 0.712 | 0.124 | 0.025 | 0.232 | 7 |
| ToN-IoT | HistGB | TPR_pooled_oracle | 0.815 | 0.619 | 0.196 | 0.090 | 0.308 | 8 |
| ToN-IoT | HistGB | TPR_reweighted_oracle | 0.815 | 0.681 | 0.134 | 0.044 | 0.230 | 8 |
| ToN-IoT | HistGB | TPR_unweighted_family_mean_oracle | 0.833 | 0.710 | 0.123 | 0.043 | 0.213 | 7 |
| ToN-IoT | HistGB | FPR_val | 0.010 | 0.019 | -0.009 | -0.026 | 0.005 | 6 |
| ToN-IoT | HistGB | FPR_oracle | 0.010 | 0.008 | 0.002 | 0.000 | 0.003 | 5 |
| ToN-IoT | HistGB | F1_pooled_val | 0.929 | 0.848 | 0.081 | 0.048 | 0.113 | 9 |
| ToN-IoT | HistGB | F1_reweighted_val | 0.929 | 0.867 | 0.062 | 0.031 | 0.094 | 8 |
| ToN-IoT | HistGB | F1_pooled_oracle | 0.929 | 0.883 | 0.046 | 0.014 | 0.080 | 8 |
| ToN-IoT | HistGB | F1_reweighted_oracle | 0.929 | 0.904 | 0.025 | 0.002 | 0.051 | 8 |
| ToN-IoT | MLP | TPR_pooled_val | 0.786 | 0.566 | 0.221 | 0.104 | 0.340 | 9 |
| ToN-IoT | MLP | TPR_reweighted_val | 0.786 | 0.632 | 0.154 | 0.048 | 0.264 | 8 |
| ToN-IoT | MLP | TPR_unweighted_family_mean_val | 0.816 | 0.673 | 0.143 | 0.047 | 0.244 | 8 |
| ToN-IoT | MLP | TPR_pooled_oracle | 0.784 | 0.536 | 0.248 | 0.162 | 0.333 | 10 |
| ToN-IoT | MLP | TPR_reweighted_oracle | 0.784 | 0.610 | 0.174 | 0.098 | 0.253 | 10 |
| ToN-IoT | MLP | TPR_unweighted_family_mean_oracle | 0.814 | 0.655 | 0.159 | 0.092 | 0.237 | 10 |
| ToN-IoT | MLP | FPR_val | 0.010 | 0.019 | -0.008 | -0.025 | 0.005 | 6 |
| ToN-IoT | MLP | FPR_oracle | 0.010 | 0.009 | 0.001 | 0.000 | 0.001 | 8 |
| ToN-IoT | MLP | F1_pooled_val | 0.925 | 0.839 | 0.086 | 0.052 | 0.119 | 9 |
| ToN-IoT | MLP | F1_reweighted_val | 0.925 | 0.857 | 0.068 | 0.036 | 0.101 | 8 |
| ToN-IoT | MLP | F1_pooled_oracle | 0.925 | 0.872 | 0.053 | 0.021 | 0.087 | 8 |
| ToN-IoT | MLP | F1_reweighted_oracle | 0.925 | 0.893 | 0.032 | 0.007 | 0.059 | 8 |
| ToN-IoT | RandomForest | TPR_pooled_val | 0.815 | 0.651 | 0.164 | 0.066 | 0.268 | 8 |
| ToN-IoT | RandomForest | TPR_reweighted_val | 0.815 | 0.711 | 0.104 | 0.015 | 0.201 | 7 |
| ToN-IoT | RandomForest | TPR_unweighted_family_mean_val | 0.836 | 0.698 | 0.138 | 0.039 | 0.241 | 7 |
| ToN-IoT | RandomForest | TPR_pooled_oracle | 0.807 | 0.652 | 0.155 | 0.073 | 0.244 | 8 |
| ToN-IoT | RandomForest | TPR_reweighted_oracle | 0.807 | 0.711 | 0.096 | 0.025 | 0.174 | 8 |
| ToN-IoT | RandomForest | TPR_unweighted_family_mean_oracle | 0.828 | 0.675 | 0.153 | 0.073 | 0.238 | 9 |
| ToN-IoT | RandomForest | FPR_val | 0.011 | 0.022 | -0.012 | -0.031 | 0.005 | 6 |
| ToN-IoT | RandomForest | FPR_oracle | 0.010 | 0.010 | 0.000 | 0.000 | 0.001 | 8 |
| ToN-IoT | RandomForest | F1_pooled_val | 0.927 | 0.844 | 0.083 | 0.040 | 0.128 | 8 |
| ToN-IoT | RandomForest | F1_reweighted_val | 0.927 | 0.864 | 0.063 | 0.022 | 0.109 | 8 |
| ToN-IoT | RandomForest | F1_pooled_oracle | 0.928 | 0.875 | 0.053 | 0.016 | 0.091 | 8 |
| ToN-IoT | RandomForest | F1_reweighted_oracle | 0.928 | 0.897 | 0.031 | 0.001 | 0.067 | 7 |

## Order of the corrections

The two corrections do not commute, so the family-mix and threshold terms are given in both orders and averaged (the remainder is the same in both). F1 terms are in F1 units (x100 for points).

| source | model | metric | total | mix (mix first) | threshold (mix first) | threshold (threshold first) | mix (threshold first) | mix (average) | threshold (average) | remainder |
|---|---|---|---|---|---|---|---|---|---|---|
| CSE-CIC-IDS2018 | HistGB | F1 | 0.014 | 0.013 | 0.001 | 0.001 | 0.013 | 0.013 | 0.001 | -0.000 |
| CSE-CIC-IDS2018 | HistGB | TPR | 0.019 | 0.023 | -0.000 | -0.000 | 0.023 | 0.023 | -0.000 | -0.003 |
| CSE-CIC-IDS2018 | MLP | F1 | 0.017 | 0.014 | 0.001 | 0.001 | 0.014 | 0.014 | 0.001 | 0.002 |
| CSE-CIC-IDS2018 | MLP | TPR | 0.022 | 0.024 | -0.000 | -0.000 | 0.024 | 0.024 | -0.000 | -0.002 |
| CSE-CIC-IDS2018 | RandomForest | F1 | 0.015 | 0.009 | 0.002 | 0.001 | 0.011 | 0.010 | 0.002 | 0.004 |
| CSE-CIC-IDS2018 | RandomForest | TPR | 0.020 | 0.023 | -0.000 | -0.000 | 0.023 | 0.023 | -0.000 | -0.003 |
| ToN-IoT | HistGB | F1 | 0.081 | 0.019 | 0.037 | 0.035 | 0.021 | 0.020 | 0.036 | 0.025 |
| ToN-IoT | HistGB | TPR | 0.199 | 0.060 | 0.005 | 0.003 | 0.062 | 0.061 | 0.004 | 0.134 |
| ToN-IoT | MLP | F1 | 0.086 | 0.018 | 0.036 | 0.033 | 0.021 | 0.020 | 0.034 | 0.032 |
| ToN-IoT | MLP | TPR | 0.221 | 0.066 | -0.019 | -0.027 | 0.074 | 0.070 | -0.023 | 0.174 |
| ToN-IoT | RandomForest | F1 | 0.083 | 0.020 | 0.032 | 0.030 | 0.022 | 0.021 | 0.031 | 0.031 |
| ToN-IoT | RandomForest | TPR | 0.164 | 0.060 | 0.009 | 0.009 | 0.059 | 0.060 | 0.009 | 0.096 |

## Interpretation

**CSE-CIC-IDS2018: the whole random-vs-episode gap is family mix.** Pooled TPR gap +0.019 to +0.022
and F1 gap +1.4 to +1.7 points. At the full-data family mix the TPR gap is −0.002 to −0.003 (CIs include
0) and the F1 gap +0.1 to +0.6 points. Threshold transfer plays no part (FPR reached 0.010–0.011 in both
splits).

**ToN-IoT, weighted F1 (the "+8 points"):**

| Model | Pooled, frozen thresholds | − family mix | − threshold transfer (oracle F1 threshold) | Remaining |
|---|---|---|---|---|
| HistGB | +8.1 | +6.2 (mix ≈ 1.9) | +2.5 (threshold ≈ 3.7) | **+2.5 [0.2, 5.1]** |
| RF | +8.3 | +6.3 (≈ 2.0) | +3.1 (≈ 3.2) | **+3.1 [0.1, 6.7]** |
| MLP | +8.6 | +6.8 (≈ 1.8) | +3.2 (≈ 3.6) | **+3.2 [0.7, 5.9]** |

Points of weighted F1, mean of 10 paired seeds, bootstrap 95% CI for the remainder. Of about 8 points,
roughly 2 are family mix, 3–4 are the F1 threshold failing to transfer from validation to test, and
2.5–3 remain.

**ToN-IoT, TPR at 1% FPR:** pooled +0.164 to +0.221; at the full-data family mix +0.104 to +0.154; with
both splits at exactly 1% test FPR +0.096 to +0.174 (CIs exclude 0). For this metric threshold transfer
is small: the episode split's validation threshold lets it reach 1.9–2.2% test FPR, which flatters the
episode split rather than penalising it.

**Where the remainder sits (oracle threshold, full-data family mix, HistGB):** almost entirely in the
single-episode families split chronologically within their episode, xss (+0.356 per family,
contribution +0.094) and password (+0.221, +0.033). Under random rows their test flows are interleaved
with training flows of the same episode; under the episode split the model is trained on the early part
of the episode and tested on the later part. Cross-episode families contribute +0.003 in total (DDoS
+0.058 offset by scanning −0.164). RF and MLP show the same pattern (fallback +0.080 / +0.152,
cross-episode +0.013 / +0.019).

**Status of C4:** the random-split inflation holds on ToN-IoT, but it is not mainly about unseen
episodes. About a quarter of it is family mix, and for F1 a large part is threshold transfer. The rest
is temporal leakage within single long episodes. On CSE-CIC-IDS2018 it is family mix only.
Across episodes there is no detectable penalty at this number of episodes.

**Order of the corrections:** applying the threshold correction first instead changes the family-mix and threshold terms by at most 0.8 percentage points (TPR) and 0.4 F1 points; the remainder is identical. The table above gives both orders and their average; the paper reports the average.
