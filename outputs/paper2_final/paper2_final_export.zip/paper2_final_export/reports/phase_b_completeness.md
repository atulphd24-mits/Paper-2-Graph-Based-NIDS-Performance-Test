# Phase B completeness check (seeds 10-29)

Read-only; counts only, no detection metrics.

## Run integrity

| part | meta_status | commit | dirty | seeds_10_29 | log_end | done_lines | expected_done |
|---|---|---|---|---|---|---|---|
| hl_ctx_main | finished | 601f92f | False | True | end | 40 | 40 |
| hl_gated | finished | 601f92f | False | True | end | 40 | 40 |
| hl_egs_ind_ToN_IoT | finished | 601f92f | False | True | end | 20 | 20 |
| hl_egs_ind_CSE_CIC_IDS2018 | finished | 601f92f | False | True | end | 20 | 20 |

## Result rows

| part | result_rows | expected_combos | missing | unexpected | duplicated (combo, subset) | subset patterns |
|---|---|---|---|---|---|---|
| hl_ctx_main | 480 | 160 | 0 | 0 | 0 | all,cross-episode,fallback: 160 |
| hl_gated | 1200 | 400 | 0 | 0 | 0 | all,cross-episode,fallback: 400 |
| hl_egs_ind_ToN_IoT | 120 | 40 | 0 | 0 | 0 | all,cross-episode,fallback: 40 |
| hl_egs_ind_CSE_CIC_IDS2018 | 120 | 40 | 0 | 0 | 0 | all,cross-episode,fallback: 40 |

## Prediction files

| part | prediction_files | expected_files | file_issues | examples |
|---|---|---|---|---|
| hl_ctx_main | 40 | 40 | 0 |  |
| hl_gated | 80 | 80 | 0 |  |
| hl_egs_ind_ToN_IoT | 20 | 20 | 0 |  |
| hl_egs_ind_CSE_CIC_IDS2018 | 20 | 20 | 0 |  |
