# Tie sensitivity (post-hoc deviation, supplement only)

Post-hoc sensitivity analysis (DEVIATION from the frozen protocol, supplement only) for the cells
whose alert threshold is tied with the maximum score (stats/threshold_ties.csv).

Under the frozen rule an alert is `score > tau`, tau = 99th percentile of validation benign scores.
If >= 1% of validation benign flows share the maximum score, tau equals that maximum and no flow can
alert: the model cannot operate at 1% FPR. This script recomputes those cells with `score >= tau`
and reports the FPR that rule actually reaches on test, next to the frozen-rule values.

Usage: python scripts/tie_sensitivity.py
Writes outputs/paper2_final/stats/tie_sensitivity_ge.csv and reports/tie_sensitivity_ge.md.

Means over seeds. `tied_seeds`: seeds in which the threshold equals the maximum score. Frozen-rule values (`>`) in the main text are shown as "cannot operate at 1% FPR (tied scores)" for these cells.

| part | source | protocol | score | seeds | tied_seeds | FPR_test > | TPR(iii) > | TPR(i) > | FPR_test >= | TPR(iii) >= | TPR(i) >= |
|---|---|---|---|---|---|---|---|---|---|---|---|
| context_final_ctx_main | ToN_IoT | episodes_gap_1_min_embargo_5_min | MLP|flow + host | 10 | 2 | 0.010 | 0.263 | 0.309 | 0.031 | 0.282 | 0.345 |
| context_final_ctx_main | ToN_IoT | episodes_gap_1_min_embargo_5_min | MLP|flow + neighbourhood + host | 10 | 5 | 0.007 | 0.219 | 0.266 | 0.030 | 0.284 | 0.356 |
| context_final_ctx_main | ToN_IoT | episodes_gap_1_min_embargo_5_min | RandomForest|flow + host | 10 | 6 | 0.012 | 0.326 | 0.273 | 0.023 | 0.464 | 0.428 |
| context_final_ctx_main | ToN_IoT | episodes_gap_1_min_embargo_5_min | RandomForest|flow + neighbourhood + host | 10 | 6 | 0.013 | 0.326 | 0.275 | 0.018 | 0.475 | 0.439 |
| splits_final_splits | CSE_CIC_IDS2018 | chronological_embargo_5_min | HistGB|timestamp only | 10 | 10 | 0.000 | 0.000 | nan | 1.000 | 0.154 | nan |
| splits_final_splits | CSE_CIC_IDS2018 | episodes_gap_1_min_embargo_5_min | HistGB|timestamp only | 10 | 7 | 0.014 | 0.000 | 0.000 | 0.022 | 0.000 | 0.000 |
| splits_final_splits | ToN_IoT | chronological_embargo_5_min | HistGB|timestamp only | 10 | 10 | 0.000 | 0.000 | nan | 1.000 | 0.814 | nan |
| splits_final_splits | ToN_IoT | chronological_embargo_5_min | RandomForest|behaviour | 10 | 10 | 0.000 | 0.000 | nan | 0.030 | 0.299 | nan |
| splits_final_splits | ToN_IoT | episodes_gap_1_min_embargo_5_min | HistGB|timestamp only | 10 | 4 | 0.097 | 0.000 | 0.000 | 0.098 | 0.000 | 0.000 |
| splits_final_unsw_splits | UNSW_NB15_original | chronological_embargo_5_min | HistGB|timestamp only | 10 | 10 | 0.000 | 0.000 | nan | 1.000 | 1.000 | nan |
| splits_final_unsw_splits | UNSW_NB15_original | episodes_gap_1_min_embargo_5_min | HistGB|timestamp only | 10 | 6 | 0.111 | 0.053 | 0.044 | 0.204 | 0.096 | 0.086 |
