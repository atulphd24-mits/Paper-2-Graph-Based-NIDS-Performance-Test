# Old (tumbling) vs new (past-only) host features

Relative change = |new − old| / max(|old|, |new|). Full tables: `host_feature_diff.csv`, `host_feature_lookahead.csv`.

## Per source and window (all flows)

| source | window | share_changed | median_rel | p95_rel | spearman |
|---|---|---|---|---|---|
| BoT-IoT | 10s | 0.411 | 0.000 | 0.711 | 0.948 |
| BoT-IoT | 1s | 0.309 | 0.000 | 0.556 | 0.964 |
| BoT-IoT | 60s | 0.518 | 0.000 | 0.782 | 0.947 |
| CSE-CIC-IDS2018 | 10s | 0.369 | 0.000 | 0.522 | 0.957 |
| CSE-CIC-IDS2018 | 1s | 0.295 | 0.000 | 0.240 | 0.945 |
| CSE-CIC-IDS2018 | 60s | 0.445 | 0.000 | 0.754 | 0.961 |
| ToN-IoT | 10s | 0.654 | 0.003 | 0.620 | 0.976 |
| ToN-IoT | 1s | 0.502 | 0.000 | 0.628 | 0.957 |
| ToN-IoT | 60s | 0.715 | 0.004 | 0.580 | 0.981 |
| UNSW-NB15 | 10s | 0.563 | 0.083 | 0.529 | 0.870 |
| UNSW-NB15 | 1s | 0.320 | 0.000 | 0.637 | 0.794 |
| UNSW-NB15 | 60s | 0.685 | 0.086 | 0.561 | 0.859 |
| UNSW-NB15 (original) | 10s | 0.553 | 0.040 | 0.523 | 0.912 |
| UNSW-NB15 (original) | 1s | 0.277 | 0.000 | 0.667 | 0.892 |
| UNSW-NB15 (original) | 60s | 0.674 | 0.061 | 0.549 | 0.908 |

Values are averages / medians over the 26 features of each window.

## 10 most-changed features, benign flows (by mean relative change)

**BoT-IoT:** `src1s_port_entropy` (0.59), `pair1s_port_entropy` (0.48), `dst60s_no_reply_ratio` (0.32), `src10s_port_entropy` (0.17), `src60s_flows` (0.16), `dst1s_port_entropy` (0.16), `dst10s_port_entropy` (0.16), `dst60s_peers` (0.15), `src10s_flows` (0.14), `dst60s_flows` (0.14)

**CSE-CIC-IDS2018:** `src60s_flows` (0.36), `src10s_flows` (0.35), `src60s_port_ratio` (0.34), `src10s_port_ratio` (0.32), `src1s_port_entropy` (0.31), `src60s_peers` (0.31), `src10s_peers` (0.28), `pair60s_flows` (0.26), `pair60s_port_ratio` (0.26), `src1s_flows` (0.25)

**ToN-IoT:** `pair1s_flows` (0.21), `pair60s_flows` (0.20), `dst1s_flows` (0.20), `src1s_flows` (0.20), `pair10s_flows` (0.20), `dst10s_flows` (0.18), `dst60s_flows` (0.17), `src10s_flows` (0.17), `pair1s_dst_ports` (0.17), `dst1s_dst_ports` (0.16)

**UNSW-NB15:** `pair1s_port_entropy` (0.52), `dst1s_port_entropy` (0.41), `pair10s_port_entropy` (0.40), `src1s_flows` (0.35), `pair10s_tiny_flow_ratio` (0.34), `src1s_port_entropy` (0.34), `dst1s_tiny_flow_ratio` (0.34), `pair10s_flows` (0.33), `pair60s_tiny_flow_ratio` (0.32), `dst1s_flows` (0.32)

**UNSW-NB15 (original):** `pair1s_port_entropy` (0.50), `dst1s_port_entropy` (0.47), `src1s_port_entropy` (0.41), `src1s_flows` (0.36), `pair10s_port_entropy` (0.34), `dst1s_flows` (0.33), `pair60s_tiny_flow_ratio` (0.31), `src1s_dst_ports` (0.28), `pair10s_flows` (0.28), `dst10s_tiny_flow_ratio` (0.25)

## 10 most-changed features, attack flows (by mean relative change)

**BoT-IoT:** `src10s_port_entropy` (0.71), `dst60s_port_entropy` (0.51), `src1s_port_entropy` (0.48), `dst10s_port_entropy` (0.44), `pair10s_flows` (0.42), `src10s_flows` (0.42), `dst10s_flows` (0.42), `dst10s_port_ratio` (0.39), `src1s_flows` (0.36), `pair1s_flows` (0.35)

**CSE-CIC-IDS2018:** `dst60s_port_entropy` (0.57), `src1s_flows` (0.26), `pair1s_flows` (0.26), `pair1s_port_ratio` (0.25), `src1s_port_ratio` (0.25), `dst1s_flows` (0.25), `dst1s_port_ratio` (0.25), `dst60s_tiny_flow_ratio` (0.17), `src1s_port_entropy` (0.16), `dst60s_no_reply_ratio` (0.16)

**ToN-IoT:** `dst1s_port_entropy` (0.40), `src1s_port_entropy` (0.29), `pair1s_port_entropy` (0.27), `dst1s_flows` (0.24), `src1s_flows` (0.24), `pair1s_flows` (0.24), `src60s_no_reply_ratio` (0.23), `pair10s_flows` (0.23), `src1s_port_ratio` (0.22), `pair60s_flows` (0.22)

**UNSW-NB15:** `src1s_port_entropy` (0.70), `dst1s_port_entropy` (0.55), `dst10s_port_entropy` (0.46), `pair60s_port_entropy` (0.43), `pair10s_port_entropy` (0.42), `dst60s_no_reply_ratio` (0.31), `src60s_no_reply_ratio` (0.31), `dst60s_tiny_flow_ratio` (0.30), `src10s_port_entropy` (0.28), `src60s_tiny_flow_ratio` (0.27)

**UNSW-NB15 (original):** `src1s_port_entropy` (0.61), `dst10s_port_entropy` (0.46), `pair60s_port_entropy` (0.42), `src1s_flows` (0.31), `pair60s_port_ratio` (0.30), `dst1s_flows` (0.29), `src10s_port_entropy` (0.29), `dst60s_port_ratio` (0.28), `pair60s_flows` (0.28), `pair10s_port_entropy` (0.28)

## Look-ahead of the old 60-second features into the flow's own attack episode

Share of sampled attack flows whose old 60-s window contained later flows of the same source host and same class (always in the same 1-minute-gap episode).

| source | attack_flows | share_with_lookahead | median_future_flows | p95_future_flows |
|---|---|---|---|---|
| BoT-IoT | 61743 | 0.995 | 11231.000 | 46516.000 |
| CSE-CIC-IDS2018 | 204897 | 0.975 | 596.000 | 3940.000 |
| ToN-IoT | 149922 | 0.993 | 500.000 | 11512.000 |
| UNSW-NB15 | 91109 | 0.871 | 8.000 | 61.000 |
| UNSW-NB15 (original) | 97221 | 0.859 | 15.000 | 710.000 |
