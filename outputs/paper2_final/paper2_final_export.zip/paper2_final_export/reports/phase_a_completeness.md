# Phase A completeness check (seeds 0-9)

Read-only; counts only, no detection metrics. Splits recomputed independently with `Data.make_split` and compared with the saved prediction rows.

## Run integrity

| part | meta_status | commit | dirty | seeds | log_end | done_lines | expected_done |
|---|---|---|---|---|---|---|---|
| splits | finished | e800706 | False | True | end | 20 | 20 |
| ctx_main | finished | 601f92f | False | True | end | 20 | 20 |
| ctx_gap5 | finished | 601f92f | False | True | end | 20 | 20 |
| ctx_chrono | finished | 601f92f | False | True | end | 20 | 20 |
| ctx_e0 | finished | 601f92f | False | True | end | 20 | 20 |
| gated | finished | 601f92f | False | True | end | 20 | 20 |
| unsw_splits | finished | 601f92f | False | True | end | 10 | 10 |
| unsw_context | finished | 601f92f | False | True | end | 10 | 10 |
| ciciot_splits | finished | 601f92f | False | True | end | 10 | 10 |
| ciciot_context | finished | 601f92f | False | True | end | 10 | 10 |
| egs_ind | finished | e800706 | False | True | end | 40 | 40 |
| egs_tr | finished | 601f92f | False | True | end | 40 | 40 |
| unsw_egs | finished | 601f92f | False | True | end | 20 | 20 |

## Result rows

| part | result_rows | expected_combos | missing | unexpected | duplicated (combo, subset) | subset patterns |
|---|---|---|---|---|---|---|
| splits | 480 | 240 | 0 | 0 | 0 | all,fallback: 80; all,cross-episode,fallback: 80; all: 80 |
| ctx_main | 720 | 240 | 0 | 0 | 0 | all,cross-episode,fallback: 240 |
| ctx_gap5 | 180 | 80 | 0 | 0 | 0 | all,fallback: 60; all,cross-episode,fallback: 20 |
| ctx_chrono | 160 | 80 | 0 | 0 | 0 | all,fallback: 80 |
| ctx_e0 | 240 | 80 | 0 | 0 | 0 | all,cross-episode,fallback: 80 |
| gated | 600 | 200 | 0 | 0 | 0 | all,cross-episode,fallback: 200 |
| unsw_splits | 200 | 120 | 0 | 0 | 0 | all,fallback: 40; all,cross-episode: 40; all: 40 |
| unsw_context | 240 | 120 | 0 | 0 | 0 | all,cross-episode: 120 |
| ciciot_splits | 30 | 30 | 0 | 0 | 0 | all: 30 |
| ciciot_context | 60 | 60 | 0 | 0 | 0 | all: 60 |
| egs_ind | 320 | 160 | 0 | 0 | 0 | all,cross-episode,fallback: 80; all: 80 |
| egs_tr | 240 | 120 | 0 | 0 | 0 | all,cross-episode,fallback: 60; all: 60 |
| unsw_egs | 180 | 120 | 0 | 0 | 0 | all,cross-episode: 60; all: 60 |

## Prediction files

| part | prediction_files | expected_files | file_issues | examples |
|---|---|---|---|---|
| splits | 60 | 60 | 0 |  |
| ctx_main | 20 | 20 | 0 |  |
| ctx_gap5 | 20 | 20 | 0 |  |
| ctx_chrono | 20 | 20 | 0 |  |
| ctx_e0 | 20 | 20 | 0 |  |
| gated | 40 | 40 | 0 |  |
| unsw_splits | 30 | 30 | 10 | seed0_chronological_embargo_5_min.parquet: constant HistGB|timestamp only; seed1_chronological_embargo_5_min.parquet: constant HistGB|timestamp only; seed2_chronological_embargo_5_min.parquet: constant HistGB|timestamp only |
| unsw_context | 10 | 10 | 0 |  |
| ciciot_splits | 10 | 10 | 0 |  |
| ciciot_context | 10 | 10 | 0 |  |
| egs_ind | 40 | 40 | 0 |  |
| egs_tr | 40 | 40 | 0 |  |
| unsw_egs | 20 | 20 | 0 |  |
