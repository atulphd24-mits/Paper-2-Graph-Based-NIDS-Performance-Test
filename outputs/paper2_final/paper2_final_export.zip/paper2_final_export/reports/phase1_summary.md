# Phase 1 summary — paper 2 final run

Branch `paper2-final`. Frozen protocol: `PROTOCOL_FREEZE.md`; statistics families declared before any
statistic was computed: `reports/stats_protocol.md` (commit 2f8a4ff). Run: option (b-ii), launched
from e800706 (16 Oct 12:47), finished 19 Oct 21:12, no failures. Completeness verified:
`reports/phase_a_completeness.md`, `reports/phase_b_completeness.md` (every expected result row and
prediction file present, no duplicates, prediction rows identical to independently recomputed splits).

Every number below comes from `outputs/paper2_final/stats/*.csv` (new run) or
`outputs/paper2_final/v1_baseline/` (v1). Metric: design-weighted TPR at 1% FPR (threshold = 99th
percentile of validation benign scores), mean over seeds with paired/seed bootstrap 95% CI. Subset
(i) = cross-episode attacks (primary), (iii) = all test attacks. p = Holm-adjusted Wilcoxon within the
declared family. HistGB at the main protocol uses 30 seeds; everything else 10.

## 1. Headline numbers (main protocol: 1-min gap, 5-min embargo; HistGB, flow features, 30 seeds)

| Source | v1 (60k, old protocol) | New (iii) all | New (i) cross-episode | Test FPR reached (mean / max) |
|---|---|---|---|---|
| ToN-IoT | 0.825 | 0.652 [0.578, 0.723] | 0.629 [0.571, 0.689] | 0.020 / 0.073 |
| CSE-CIC-IDS2018 | 0.919 | 0.933 [0.929, 0.937] | **0.543 [0.455, 0.637]** | 0.011 / 0.018 |

- **CSE-CIC-IDS2018: the overall 0.93 is dominated by single-episode families tested within their own
  episode** (subset (ii) = 1.000, 84% of the test-attack weight). On the only families testable on
  unseen episodes the rate is 0.54. Post-hoc check (deviation, `reports/posthoc_same_family.md`):
  at equal family mix, unseen episodes change TPR by only −0.058 [−0.139, +0.028]. The drop is a
  family effect: Infiltration carries 94% of the subset (i) weight and is detected at 0.43.
- **ToN-IoT: the drop from v1 (0.825) comes from the split fixes, not from the host-feature fix** —
  flow-only features are unaffected by fix A. Full-data episodes, the embargo, constrained episode
  assignment and the stratified, design-weighted sample all contribute; they are not separated here.
- **Thresholds do not transfer on ToN-IoT:** the FPR reached on test averages 2.0% (target 1%), up to
  7.3% for flow features and up to 32% with host features (section 3, C6).

## 2. Claims check (v1 abstract) on subset (i)

| # | v1 claim | Status | Evidence (new run) |
|---|---|---|---|
| C1–C3 | Source identifiable (99.4% bal. acc.), timestamp-only F1 0.85 pooled, 56% of ToN-IoT attack flows duplicate benign ones | **Not re-run; unaffected** | Data properties; independent of fixes A/B and of the splits. Numbers remain those of `v1_baseline/leakage_study/part1_*`, `label_ambiguity_*`. |
| C4 | Random row splits inflate ToN-IoT weighted F1 by 3–6 points for four model families; timestamp-only falls to zero at an episode split | **Holds, stronger** | ToN-IoT weighted F1 (iii): random 0.929 vs episodes 0.848 (HistGB), RF 0.927 vs 0.844, MLP 0.925 vs 0.839 → +8 points. TPR@1%FPR (iii): +0.164 to +0.221, p ≤ 0.020. CSE-CIC +0.019 to +0.022 (p = 0.004); UNSW-NB15 +0.016 to +0.024 (p ≤ 0.020). Timestamp-only: 0.000 at the episode split on ToN-IoT and CSE-CIC (some seeds tied, section 5), 0.12–0.13 on random rows (p = 0.002). |
| C5 | Graph-neighbourhood and host context improve CSE-CIC for GB, RF, MLP and E-GraphSAGE (+0.03 to +0.05) | **Split: host holds and is larger on (i); k-NN neighbourhood reverses** | Host, (i): HistGB +0.160 [0.112, 0.203] (30 seeds, p < 0.001), RF +0.152, MLP +0.175 (p = 0.012). Host, (iii): +0.021 to +0.026. **Neighbourhood features (now inductive, fix B), (i): HistGB −0.007 [−0.009, −0.004] (p < 0.001), RF −0.004, MLP +0.007; (iii): −0.002 to −0.005.** E-GraphSAGE (IP, validation-chosen) vs HistGB, (i): +0.087 [0.061, 0.115] (30 seeds, p < 0.001); the random-endpoint control is −0.024, so the gain comes from real IP structure. |
| C6 | Context never reliably helps on ToN-IoT | **Reversed to "hurts"** | Host, (i): HistGB −0.172 [−0.242, −0.106] (30 seeds, p < 0.001); (iii) −0.249. RF and MLP drop more (−0.25 to −0.32) but are partly a threshold-tie artifact (section 5). Neighbourhood ≈ 0 (HistGB +0.001; MLP +0.031, p = 0.006). E-GraphSAGE (IP:port, validation-chosen), (i): −0.115 [−0.152, −0.079] (30 seeds, p < 0.001). With host features the test FPR reaches up to 26–32% in some seeds. |
| C7 | The family-gated detector matches the best feature set on both datasets | **Weakened: matches only when validation is reused; otherwise a safe default** | Split validation (primary), (i): ToN-IoT gated 0.556 vs flow 0.642 (flow − gated +0.086 [0.028, 0.155], p = 0.121) and vs host 0.469 (gated better by 0.087, p = 0.027); CSE-CIC gated 0.644 vs host 0.703 (+0.059 [0.016, 0.103], p = 0.164) and vs flow 0.544 (gated better by 0.100, p = 0.014). Reused validation: ToN 0.627 vs flow 0.629, CSE-CIC 0.712 vs host 0.703. So the v1 match came from choosing experts and setting thresholds on the same validation data. With an honest split it sits 6–9 points below the best single feature set (bootstrap CIs exclude 0; Holm-adjusted Wilcoxon not significant) and clearly above the worst. |
| C8 | External: every benchmark has a single-feature shortcut; only episode splits remove the timestamp shortcut; context value is dataset-specific | **Shortcut part not re-run; timestamp part needs rewording; context part holds** | UNSW-NB15 timestamp-only: episodes 0.055, random 0.093 (n.s.), chronological 0.000 (constant score). The chronological split removes it too, and the UNSW episode split does not fully. Context: UNSW host +0.002 to +0.011 on (i); CIC-IoT2023 neighbourhood −0.000 to −0.001. |

## 3. Additional findings (new run only)

- **Temporal drift on ToN-IoT.** Chronological reference vs main protocol, (iii): HistGB 0.168 vs
  0.621 (−0.453, p = 0.006); MLP 0.082; RF 0.000 (tie artifact). CSE-CIC is unaffected (0.942 vs
  0.935). Host features partly recover ToN-IoT under the chronological split (+0.219, p = 0.006).
- **Embargo and gap (HistGB, flow, (iii)).** E = 0 vs E = 5: ToN-IoT +0.038 (n.s.), CSE-CIC 0.000. The
  5-min gap is more optimistic: ToN-IoT +0.146 (n.s.), CSE-CIC +0.065 (p = 0.006), reaching 1.000
  on subset (iii) over 14.2 test episodes, 11 of them fallback, because more families fall back to
  within-episode splits. Subset (i) exists only for ToN-IoT in 5 of 10 seeds (3.2 test episodes on
  average) and never for CSE-CIC, which justifies the 1-min main gap.
- **Inductive vs transductive E-GraphSAGE** differ little: on (i) |Δ| ≤ 0.033 on BigFlow (largest
  ToN-IoT IP:port −0.033, p = 0.041 after the F7 Holm correction). UNSW-NB15 IP −0.134 is not significant. The transductive leak in
  E-GraphSAGE is small at this scale.
- **Episode-level uncertainty is large.** Median within-seed episode-bootstrap CI for HistGB flow on
  (i): ToN-IoT [0.17, 0.99] (39 test episodes), CSE-CIC [0.56, 0.99] (30). Seed-level CIs (table 1)
  understate how much the result depends on which episodes are tested.

## 4. Families that allow only within-episode evaluation (main protocol, 30 seeds)

| Source | Family | Excluded from (i) | Reason |
|---|---|---|---|
| CSE-CIC-IDS2018 | Bot, DDOS-HOIC, DDOS-LOIC-UDP, DoS-Hulk, DoS-SlowHTTPTest, DoS-Slowloris, FTP-BruteForce, SSH-Bruteforce | 30/30 | 1 full-data episode (chronological fallback) |
| CSE-CIC-IDS2018 | Brute_Force-XSS (480 flows), SQL_Injection (440 flows) | 30/30 | < 500 training flows (whole class < 500) |
| CSE-CIC-IDS2018 | DoS-GoldenEye | 30/30 | 5 episodes → < 3 test episodes |
| CSE-CIC-IDS2018 | Infiltration | 6/30 | < 3 test episodes in some seeds |
| ToN-IoT | DoS (1 episode), password (2), xss (2) | 30/30 | < 3 full-data episodes (chronological fallback) |
| ToN-IoT | injection | 27/30 | < 3 test episodes in most seeds |
| ToN-IoT | mitm | 15/30 | < 3 test episodes in half the seeds |
| ToN-IoT | ransomware | 11/30 | < 3 test episodes in some seeds |

Families evaluated cross-episode in every seed: ToN-IoT Backdoor, DDoS, scanning; CSE-CIC
Brute_Force-Web, DDoS-LOIC-HTTP (and Infiltration in 24/30).

## 5. Issue needing a decision: threshold ties under the frozen `score > τ` rule

When at least 1% of validation benign flows share the maximum score, τ equals that maximum and no
test flow can exceed it, so TPR is 0 even when attacks are ranked at the top. Scan of all 2,290 score
columns (`stats/threshold_ties.csv`): 76 affected, in 11 of 197 cells:
- **timestamp-only control** (7 cells): expected; reported as "no detection (constant or tied score)";
- **RF, ToN-IoT, chronological split:** 10/10 seeds. 2.45% of validation benign flows score 1.0 and
  about 9,700 test attack flows per seed also score 1.0, so TPR = 0.000;
- **RF and MLP with host features, ToN-IoT, main protocol:** 2–6 of 10 seeds. This inflates the RF/MLP
  host-feature drop in C6.

No HistGB behaviour model, gated detector, E-GraphSAGE or 30-seed headline cell is affected, so C6
stands on HistGB alone. The frozen rule stays the primary analysis; changing it now would be a
deviation. Options: (a) report as is and flag the 11 cells; (b) add a sensitivity analysis with
`score ≥ τ`, reporting the FPR it reaches (2.45% for the RF chronological cell), labelled as a
post-hoc deviation.

## 6. Not reported in paper 2

Response-time metrics (a)–(d) are computed separately into `outputs/paper3_baseline/` (paper 3).

## Files

- Tests: `stats/tests_all_families.csv` (F1–F8, both metrics, subsets (i) and (iii))
- Descriptive: `stats/{splits,context,gated,egraphsage}_descriptive.csv`
- Old vs new: `stats/old_vs_new.csv`; ties: `stats/threshold_ties.csv`
