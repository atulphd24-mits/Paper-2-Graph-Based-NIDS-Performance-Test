# Expected disk size of per-flow predictions

Expected disk size of the per-flow prediction files for the frozen run plan (option b-i, which
contains b-ii). Rows per file = validation + test rows per source (smoke check, stratified sample,
mean over seeds 0-4); bytes per row from the UNSW-NB15 check files (zstd parquet): measured
~11 B/row metadata and 1.7-3.2 B/row per float32 score column. The upper bound assumes
uncompressed scores (4 B) and 14 B/row metadata.

Writes outputs/paper2_final/reports/prediction_disk_estimate.md.

| part | files | rows_M | score_columns | in_b_ii | expected_GB | upper_GB |
|---|---|---|---|---|---|---|
| splits | 60 | 4.991 | 4 | True | 0.105 | 0.150 |
| context HistGB main | 60 | 4.991 | 4 | True | 0.105 | 0.150 |
| context RF + MLP main | 20 | 1.664 | 8 | True | 0.052 | 0.077 |
| context HistGB gap 5 / chronological / E=0 | 60 | 4.991 | 4 | True | 0.105 | 0.150 |
| gated (reused + split validation) | 120 | 9.982 | 5 | True | 0.235 | 0.339 |
| E-GraphSAGE inductive main (+ baseline) | 60 | 4.991 | 4 | True | 0.105 | 0.150 |
| E-GraphSAGE inductive random (+ baseline) | 20 | 1.664 | 4 | True | 0.035 | 0.050 |
| E-GraphSAGE inductive gap 5 (+ baseline) | 20 | 1.664 | 4 | False | 0.035 | 0.050 |
| E-GraphSAGE transductive main / random | 40 | 3.327 | 3 | True | 0.062 | 0.087 |
| UNSW-NB15 splits | 30 | 1.762 | 4 | True | 0.037 | 0.053 |
| UNSW-NB15 context | 10 | 0.587 | 12 | True | 0.024 | 0.036 |
| UNSW-NB15 E-GraphSAGE | 20 | 1.175 | 6 | True | 0.031 | 0.045 |
| CIC-IoT2023 splits | 10 | 1.919 | 3 | True | 0.036 | 0.050 |
| CIC-IoT2023 context | 10 | 1.919 | 6 | True | 0.050 | 0.073 |

## Totals

| option | files | expected_GB | upper_GB |
|---|---|---|---|
| (b-i) | 540 | 1.01 | 1.46 |
| (b-ii) | 520 | 0.98 | 1.41 |
