# Measured runtimes (one seed, sequential, full working sample)

Wall-clock time of seed 0 for every part, scaled by the seeds in the frozen plan (10 seeds; 30 for headline parts). Machine: Xeon Silver 4310, 24 cores, no GPU.

| part | description | status | one_seed_min | seeds | total_h | in_b_i | in_b_ii |
|---|---|---|---|---|---|---|---|
| splits | Split inflation: random / episodes / chronological, HistGB+RF+MLP + timestamp-only | finished | 11.62 | 10 | 1.94 | True | True |
| ctx_hgb_main | Context features, HistGB, main protocol (G=1, E=5) | finished | 13.09 | 30 | 6.55 | True | True |
| ctx_rfmlp_main | Context features, RF + MLP, main protocol | finished | 195.12 | 10 | 32.52 | True | True |
| ctx_hgb_gap5 | Context features, HistGB, G=5, E=5 | finished | 12.21 | 10 | 2.03 | True | True |
| ctx_hgb_chrono | Context features, HistGB, chronological reference | finished | 15.46 | 10 | 2.58 | True | True |
| ctx_hgb_e0 | Context features, HistGB, G=1, E=0 | finished | 14.46 | 10 | 2.41 | True | True |
| gated | Family-gated detector (reused + split validation) | finished | 17.20 | 30 | 8.60 | True | True |
| egs_ind_gap1 | E-GraphSAGE inductive, main protocol, 3 endpoints + HistGB baseline | finished | 82.54 | 30 | 41.27 | True | True |
| egs_ind_random | E-GraphSAGE inductive, random rows | finished | 118.02 | 10 | 19.67 | True | True |
| egs_ind_gap5 | E-GraphSAGE inductive, G=5, E=5 | finished | 93.96 | 10 | 15.66 | True | False |
| egs_tr_gap1 | E-GraphSAGE transductive, main protocol | finished | 108.67 | 10 | 18.11 | True | True |
| egs_tr_random | E-GraphSAGE transductive, random rows | finished | 131.39 | 10 | 21.90 | True | True |
| unsw_splits | UNSW-NB15: split inflation | finished | 4.69 | 10 | 0.78 | True | True |
| unsw_context | UNSW-NB15: context features, HistGB+RF+MLP, main protocol | finished | 13.51 | 10 | 2.25 | True | True |
| unsw_egs | UNSW-NB15: E-GraphSAGE inductive + transductive, random + main | finished | 154.99 | 10 | 25.83 | True | True |
| ciciot_splits | CIC-IoT2023: random split | finished | 66.79 | 10 | 11.13 | True | True |
| ciciot_context | CIC-IoT2023: flow + neighbourhood, random split | finished | 150.42 | 10 | 25.07 | True | True |

## Options

`two_lanes_h`: tabular and graph runs in two parallel lanes; the lane totals are measured sequentially, so contention between lanes is not included.

| option | sequential_h | tabular_lane_h | graph_lane_h | two_lanes_h (max) |
|---|---|---|---|---|
| (b-i) | 238.3 | 95.9 | 142.4 | 142.4 |
| (b-ii) | 222.6 | 95.9 | 126.8 | 126.8 |
