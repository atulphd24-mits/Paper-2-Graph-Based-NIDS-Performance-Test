# Smoke check: full working sample vs 60k subsample (seed 0, 1-min gap, 5-min embargo)

## Subset (i) coverage

| source | sample | subset_i_share_of_test_attacks | subset_i_attack_flows | subset_i_episodes | families_in_i | which |
|---|---|---|---|---|---|---|
| ToN-IoT | 60k subsample | 0.110 | 515 | 10 | 2 | Backdoor, DDoS |
| CSE-CIC-IDS2018 | 60k subsample | 0.031 | 163 | 17 | 2 | DDoS_attacks-LOIC-HTTP, Infilteration |
| ToN-IoT | full working sample | 0.378 | 7718 | 19 | 5 | Backdoor, DDoS, mitm, ransomware, scanning |
| CSE-CIC-IDS2018 | full working sample | 0.040 | 1084 | 41 | 3 | Brute_Force_-Web, DDoS_attacks-LOIC-HTTP, Infilteration |
| UNSW-NB15 (original) | 60k subsample | 0.702 | 3428 | 29 | 4 | Analysis, Exploits, Fuzzers, Generic |
| UNSW-NB15 (original) | full working sample | 0.703 | 10564 | 105 | 6 | Analysis, Backdoor, DoS, Fuzzers, Generic, Shellcode |

## Episodes per family

`episodes_full_data`: all flows of the class in the complete dataset; `episodes_in_sample`: episodes that contain at least one sampled flow.

| source | family | episodes_full_data | episodes_in_sample (full working sample) | episodes_in_sample (60k subsample) | test_episodes (full working sample) | test_episodes (60k subsample) | in (i) (full working sample) | in (i) (60k subsample) |
|---|---|---|---|---|---|---|---|---|
| CSE-CIC-IDS2018 | Bot | 1 | 1.000 | 1.000 | 1.000 | 1.000 | False | False |
| CSE-CIC-IDS2018 | Brute_Force_-Web | 115 | 115.000 | 79.000 | 19.000 | 15.000 | True | False |
| CSE-CIC-IDS2018 | Brute_Force_-XSS | 187 | 187.000 | 71.000 | 25.000 | 10.000 | False | False |
| CSE-CIC-IDS2018 | DDOS_attack-HOIC | 1 | 1.000 | 1.000 | 1.000 | 1.000 | False | False |
| CSE-CIC-IDS2018 | DDOS_attack-LOIC-UDP | 1 | 1.000 | 1.000 | 1.000 | 1.000 | False | False |
| CSE-CIC-IDS2018 | DDoS_attacks-LOIC-HTTP | 11 | 11.000 | 8.000 | 9.000 | 6.000 | True | True |
| CSE-CIC-IDS2018 | DoS_attacks-GoldenEye | 5 | 4.000 | 4.000 | 1.000 | 1.000 | False | False |
| CSE-CIC-IDS2018 | DoS_attacks-Hulk | 1 | 1.000 | 1.000 | 1.000 | 1.000 | False | False |
| CSE-CIC-IDS2018 | DoS_attacks-SlowHTTPTest | 1 | 1.000 | 1.000 | 1.000 | 1.000 | False | False |
| CSE-CIC-IDS2018 | DoS_attacks-Slowloris | 1 | 1.000 | 1.000 | 1.000 | 1.000 | False | False |
| CSE-CIC-IDS2018 | FTP-BruteForce | 1 | 1.000 | 1.000 | 1.000 | 1.000 | False | False |
| CSE-CIC-IDS2018 | Infilteration | 23 | 17.000 | 15.000 | 13.000 | 11.000 | True | True |
| CSE-CIC-IDS2018 | SQL_Injection | 95 | 95.000 | 43.000 | 14.000 | 8.000 | False | False |
| CSE-CIC-IDS2018 | SSH-Bruteforce | 1 | 1.000 | 1.000 | 1.000 | 1.000 | False | False |
| ToN-IoT | Backdoor | 7 | 7.000 | 7.000 | 5.000 | 5.000 | True | True |
| ToN-IoT | DDoS | 8 | 8.000 | 8.000 | 5.000 | 5.000 | True | True |
| ToN-IoT | DoS | 1 | 1.000 | 1.000 | 1.000 | 1.000 | False | False |
| ToN-IoT | injection | 9 | 8.000 | 8.000 | 1.000 | 2.000 | False | False |
| ToN-IoT | mitm | 18 | 18.000 | 16.000 | 3.000 | 3.000 | True | False |
| ToN-IoT | password | 2 | 2.000 | 2.000 | 1.000 | 1.000 | False | False |
| ToN-IoT | ransomware | 18 | 18.000 | 15.000 | 3.000 | 2.000 | True | False |
| ToN-IoT | scanning | 173 | 15.000 | 7.000 | 3.000 | 1.000 | True | False |
| ToN-IoT | xss | 2 | 2.000 | 2.000 | 1.000 | 1.000 | False | False |
| UNSW-NB15 (original) | Analysis | 95 | 95.000 | 47.000 | 20.000 | 9.000 | True | True |
| UNSW-NB15 (original) | Backdoor | 233 | 233.000 | 123.000 | 29.000 | 26.000 | True | False |
| UNSW-NB15 (original) | DoS | 39 | 39.000 | 39.000 | 4.000 | 2.000 | True | False |
| UNSW-NB15 (original) | Exploits | 9 | 8.000 | 8.000 | 1.000 | 3.000 | False | True |
| UNSW-NB15 (original) | Fuzzers | 111 | 111.000 | 108.000 | 13.000 | 13.000 | True | True |
| UNSW-NB15 (original) | Generic | 28 | 26.000 | 21.000 | 6.000 | 4.000 | True | True |
| UNSW-NB15 (original) | Reconnaissance | 8 | 8.000 | 8.000 | 1.000 | 1.000 | False | False |
| UNSW-NB15 (original) | Shellcode | 239 | 239.000 | 172.000 | 33.000 | 20.000 | True | False |
| UNSW-NB15 (original) | Worms | 140 | 140.000 | 49.000 | 15.000 | 9.000 | False | False |
