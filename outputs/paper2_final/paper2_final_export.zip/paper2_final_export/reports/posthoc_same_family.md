# Post-hoc check: unseen episode or harder families? (DEVIATION, decided 2026-10-20 after results were seen)

Question: is the CSE-CIC-IDS2018 drop from 0.93 (all test attacks) to 0.54 (subset (i)) caused by
testing on unseen episodes, or by which families can be tested on unseen episodes at all?

Method (not pre-specified; from the saved predictions, no model refitted): HistGB on flow features,
seeds 0-9, the split comparison run. For each seed, take the families in subset (i) under the main
episode split, and score the same families under the random-row split of the same seed. Each split
uses its own validation threshold (99th percentile of validation benign, `score > τ`).
Design-weighted TPR, mean over seeds, seed-bootstrap 95% CI. The family-mix-standardised value applies
the episode split's subset (i) family weights to the random-row per-family TPRs.
Script output: `stats/posthoc_same_family_random*.csv`, `stats/posthoc_same_family_standardised.csv`.

## Result

| | CSE-CIC-IDS2018 | ToN-IoT |
|---|---|---|
| Episode split, subset (i) | 0.515 [0.391, 0.651] | 0.600 [0.507, 0.698] |
| Random rows, same families, own family mix | 0.774 [0.747, 0.825] | 0.745 [0.743, 0.749] |
| Random rows, same families, episode-split family mix | 0.457 [0.393, 0.578] | 0.591 [0.569, 0.625] |
| **Unseen-episode effect at equal family mix** (random − episode) | **−0.058 [−0.139, +0.028]** | **−0.008 [−0.103, +0.077]** |
| Episode split, subset (ii) (single-episode families, within-episode) | 1.000 [1.000, 1.000] | 0.621 [0.418, 0.811] |
| Episode split, subset (iii) | 0.935 | 0.621 |
| Share of test-attack design weight in (i) / (ii) | 0.111 / 0.842 | 0.465 / 0.494 |
| FPR reached on test, episode / random | 0.011 / 0.010 | 0.019 / 0.010 |

Per family (mean over seeds in which the family is in subset (i)):

| Source | Family | Episode split (i) | Random rows | Weight share in (i), episode / random |
|---|---|---|---|---|
| CSE-CIC | Brute Force-Web | 0.927 | 0.949 | 0.014 / 0.004 |
| CSE-CIC | DDoS-LOIC-HTTP | 1.000 | 1.000 | 0.137 / 0.642 |
| CSE-CIC | Infiltration | 0.428 | 0.361 | 0.943 / 0.393 |
| ToN-IoT | Backdoor | 0.955 | 0.996 | 0.003 / 0.035 |
| ToN-IoT | DDoS | 0.894 | 0.974 | 0.592 / 0.721 |
| ToN-IoT | injection (1 seed) | 0.795 | 0.979 | 0.093 / 0.063 |
| ToN-IoT | mitm (6 seeds) | 0.671 | 0.902 | 0.002 / 0.001 |
| ToN-IoT | ransomware (4 seeds) | 0.739 | 0.979 | 0.001 / 0.001 |
| ToN-IoT | scanning | 0.145 | 0.002 | 0.394 / 0.236 |

## Interpretation

- **CSE-CIC: the 0.93 → 0.54 drop is a family effect, not an unseen-episode effect.** The overall rate
  is dominated by single-episode families (84% of the test-attack weight), tested within their own
  episode and all detected (subset (ii) = 1.000). The only families testable on unseen episodes are
  Brute Force-Web, DDoS-LOIC-HTTP and Infiltration, and Infiltration carries 94% of the subset (i)
  weight. Infiltration is detected at 0.43 on unseen episodes and 0.36 under random rows. At equal
  family mix, unseen episodes change TPR by −0.058 (CI includes 0).
- **Why the family mix differs between splits:** the constrained assignment balances *sampled* flows
  (10–25% to test), while TPR is weighted by *full-data* flows (design weights). The held-out
  Infiltration episodes include large ones with large weights, and the held-out LOIC-HTTP episodes
  are small, so Infiltration dominates (i).
- **ToN-IoT: per-family unseen-episode penalties exist but cancel.** DDoS, Backdoor, mitm, ransomware
  and injection lose 0.04–0.24 on unseen episodes, while scanning is detected better on unseen episodes
  (0.145 vs 0.002, both near zero; 94% of scanning flows duplicate benign flows). At equal family mix
  the net effect is −0.008.
- **Consequence for the paper:** subset (i) measures detection on the families that can be tested
  across episodes. It should not be read as "novelty of the episode". The headline gap reflects
  which families the benchmark lets us test honestly. Report per-family TPR next to the pooled
  subset (i) value.
