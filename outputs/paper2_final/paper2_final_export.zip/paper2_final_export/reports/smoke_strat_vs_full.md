# Subset (i) coverage: episode-stratified vs previous samples

Smoke check, main protocol (1-min gap, 5-min embargo), seeds 0-4. Subset (i) = attack flows of families with >= 3 test episodes and >= 500 training flows.

## Per source (mean over 5 seeds; min/max where shown)

| source | sample | share_mean | attack_flows_mean | test_episodes_mean | test_episodes_min | families_mean | families_min | families_max |
|---|---|---|---|---|---|---|---|---|
| CSE-CIC-IDS2018 | 60k subsample | 0.03 | 163.00 | 17.00 | 17 | 2.00 | 2 | 2 |
| ToN-IoT | 60k subsample | 0.12 | 569.80 | 10.80 | 10 | 2.20 | 2 | 3 |
| CSE-CIC-IDS2018 | full working sample (20k cap) | 0.04 | 1041.80 | 38.80 | 35 | 3.00 | 3 | 3 |
| ToN-IoT | full working sample (20k cap) | 0.33 | 6533.40 | 18.60 | 14 | 4.20 | 3 | 5 |
| CSE-CIC-IDS2018 | episode-stratified sample | 0.13 | 4098.60 | 28.60 | 25 | 2.80 | 2 | 3 |
| ToN-IoT | episode-stratified sample | 0.35 | 6929.40 | 36.20 | 31 | 4.20 | 3 | 5 |
| UNSW-NB15 (original) | 60k subsample | 0.54 | 2481.80 | 28.40 | 25 | 3.40 | 3 | 4 |
| UNSW-NB15 (original) | full working sample (20k cap) | 0.68 | 10527.40 | 89.40 | 76 | 5.40 | 5 | 6 |
| UNSW-NB15 (original) | episode-stratified sample | 0.59 | 9468.20 | 82.00 | 65 | 5.00 | 4 | 6 |

## Per family

`seeds_in_i`: number of the 5 seeds in which the family enters subset (i).

| source | family | episodes_in_sample (60k subsample) | episodes_in_sample (full working sample (20k cap)) | episodes_in_sample (episode-stratified sample) | test_episodes_mean (60k subsample) | test_episodes_mean (full working sample (20k cap)) | test_episodes_mean (episode-stratified sample) | seeds_in_i (60k subsample) | seeds_in_i (full working sample (20k cap)) | seeds_in_i (episode-stratified sample) |
|---|---|---|---|---|---|---|---|---|---|---|
| CSE-CIC-IDS2018 | Bot | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | Brute_Force_-Web | 79.0 | 115.0 | 115.0 | 15.0 | 16.8 | 16.8 | 0 | 5 | 5 |
| CSE-CIC-IDS2018 | Brute_Force_-XSS | 71.0 | 187.0 | 187.0 | 11.2 | 28.6 | 28.6 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | DDOS_attack-HOIC | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | DDOS_attack-LOIC-UDP | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | DDoS_attacks-LOIC-HTTP | 8.0 | 11.0 | 11.0 | 6.0 | 9.0 | 9.0 | 5 | 5 | 5 |
| CSE-CIC-IDS2018 | DoS_attacks-GoldenEye | 4.0 | 4.0 | 5.0 | 1.0 | 1.4 | 1.2 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | DoS_attacks-Hulk | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | DoS_attacks-SlowHTTPTest | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | DoS_attacks-Slowloris | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | FTP-BruteForce | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | Infilteration | 15.0 | 17.0 | 23.0 | 11.0 | 13.0 | 3.2 | 5 | 5 | 4 |
| CSE-CIC-IDS2018 | SQL_Injection | 43.0 | 95.0 | 95.0 | 6.8 | 16.0 | 15.6 | 0 | 0 | 0 |
| CSE-CIC-IDS2018 | SSH-Bruteforce | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| ToN-IoT | Backdoor | 7.0 | 7.0 | 7.0 | 5.0 | 5.0 | 5.0 | 5 | 5 | 5 |
| ToN-IoT | DDoS | 8.0 | 8.0 | 8.0 | 5.0 | 5.0 | 5.0 | 5 | 5 | 5 |
| ToN-IoT | DoS | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| ToN-IoT | injection | 8.0 | 8.0 | 9.0 | 1.6 | 1.4 | 1.4 | 0 | 0 | 0 |
| ToN-IoT | mitm | 16.0 | 18.0 | 18.0 | 2.6 | 2.6 | 3.2 | 1 | 2 | 3 |
| ToN-IoT | password | 2.0 | 2.0 | 2.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| ToN-IoT | ransomware | 15.0 | 18.0 | 18.0 | 2.8 | 3.4 | 2.8 | 0 | 4 | 3 |
| ToN-IoT | scanning | 7.0 | 15.0 | 173.0 | 1.8 | 4.0 | 21.6 | 0 | 5 | 5 |
| ToN-IoT | xss | 2.0 | 2.0 | 2.0 | 1.0 | 1.0 | 1.0 | 0 | 0 | 0 |
| UNSW-NB15 (original) | Analysis | 47.0 | 95.0 | 95.0 | 7.4 | 14.8 | 14.8 | 5 | 5 | 5 |
| UNSW-NB15 (original) | Backdoor | 123.0 | 233.0 | 233.0 | 19.0 | 34.6 | 34.6 | 0 | 5 | 5 |
| UNSW-NB15 (original) | DoS | 39.0 | 39.0 | 39.0 | 4.0 | 6.0 | 6.0 | 3 | 5 | 5 |
| UNSW-NB15 (original) | Exploits | 8.0 | 8.0 | 9.0 | 1.6 | 1.2 | 1.6 | 1 | 0 | 0 |
| UNSW-NB15 (original) | Fuzzers | 108.0 | 111.0 | 111.0 | 15.0 | 14.8 | 16.6 | 5 | 5 | 5 |
| UNSW-NB15 (original) | Generic | 21.0 | 26.0 | 28.0 | 2.8 | 5.2 | 5.0 | 3 | 5 | 4 |
| UNSW-NB15 (original) | Reconnaissance | 8.0 | 8.0 | 8.0 | 1.4 | 1.6 | 1.2 | 0 | 0 | 0 |
| UNSW-NB15 (original) | Shellcode | 172.0 | 239.0 | 239.0 | 28.0 | 34.6 | 37.4 | 0 | 2 | 1 |
| UNSW-NB15 (original) | Worms | 49.0 | 140.0 | 140.0 | 9.0 | 20.8 | 23.6 | 0 | 0 | 0 |
