# Statistics protocol (paper 2 final)

Declared before any statistic of the final run was computed (committed with this file).

All model comparisons are **paired by seed**: each seed fixes the split and the model's random state, and every condition in a comparison uses the same seeds and the same split.

For every comparison: `mean_diff` (mean over seeds of candidate − baseline); `ci_low`, `ci_high` (paired bootstrap 95% CI, 10,000 resamples of seeds, percentile, RNG seed 0); `p_raw` (two-sided Wilcoxon signed-rank on per-seed differences; not computed with < 5 seeds or all differences 0); `p_holm` (Holm–Bonferroni within the family); `family_size`; `wins` (seeds where the candidate is higher).

Metrics: `TPR@FPR1pct` (primary) and `PR_AUC_w` (secondary), each its own family. Subsets: (i) cross-episode (primary) and (iii) all, each its own family; a comparison is tested on (i) only if every seed of every condition has subset (i) rows. Descriptive tables report means with seed-bootstrap CIs, the FPR reached on test, test episodes and the median within-seed episode-bootstrap CI for subset (i).

With 10 seeds the smallest two-sided Wilcoxon p is 0.002; with 30 seeds about 1.9e-9.

## Families of tests

- **F1 split inflation** (splits; condition `protocol`, baseline `episodes gap 1 min, embargo 5 min`, one family per (source, model, representation), metric and subset). Random rows and the chronological split vs the main episode protocol, per (source, model, representation incl. timestamp-only): 2 tests per family. Subset (iii) only: subset (i) is not defined for random rows or the chronological split. 10 seeds.
- **F2 context features (main protocol)** (context; condition `representation`, baseline `flow`, one family per (source, model, protocol), metric and subset). flow + neighbourhood, flow + host, flow + neighbourhood + host vs flow, per (source, model): 3 tests per family. HistGB 30 seeds, RF and MLP 10 seeds; external datasets 10 seeds (CIC-IoT2023: flow + neighbourhood only, random split, subset (iii)).
- **F3 context features (sensitivity protocols)** (context; condition `representation`, baseline `flow`, one family per (source, model, protocol), metric and subset). Same comparison as F2 for HistGB under the 5-min gap, the chronological reference and no embargo (E = 0), per (source, protocol): 3 tests per family. 10 seeds.
- **F4 protocol sensitivity (flow features)** (context; condition `protocol`, baseline `episodes gap 1 min, embargo 5 min`, one family per (source, model, representation), metric and subset). HistGB on flow features: 5-min gap, chronological reference and E = 0 vs the main protocol, per source: 3 tests per family. Subset (iii) (subset (i) is not available for every seed of the 5-min gap and not defined for the chronological split). 10 seeds (seeds 0-9 of the main protocol).
- **F5 family-gated detector** (gated; condition `representation`, baseline `family-gated`, one family per (source, validation), metric and subset). Each alternative (flow, flow + neighbourhood, flow + host, unweighted ensemble) vs the family-gated detector, per (source, validation version): 4 tests per family; reported differences are alternative minus gated. 30 seeds. Primary version: split validation.
- **F6 E-GraphSAGE vs flow-only HistGB** (egraphsage; condition `model`, baseline `HistGB (flow, no graph)`, one family per (source, protocol, mode), metric and subset). Each endpoint (IP, IP:port, random control) vs flow-only HistGB on the same split, per (source, protocol, training mode): 3 tests per family. Seeds 0-9.
- **F7 inductive vs transductive E-GraphSAGE** (egraphsage; condition `mode`, baseline `transductive`, one family per (source, protocol, model), metric and subset). Inductive minus transductive, per endpoint, per (source, protocol): 3 tests per family. Seeds 0-9.
- **F8 headline E-GraphSAGE (30 seeds)** (egraphsage; condition `model`, baseline `HistGB (flow, no graph)`, one family per (source, protocol), metric and subset). Inductive E-GraphSAGE with the endpoint chosen on validation PR-AUC (reports/endpoint_selection.json) vs flow-only HistGB, main protocol, per source: 1 test per family. 30 seeds.
- **Old (v1) vs new** — descriptive only, no test: v1 used the 60k-flow subsample, the leaky host features, transductive neighbourhood context and different splits, so seeds are not paired. Means per cell; new values on subsets (i) and (iii) of the main protocol, seeds 0-9.

## Not reported in paper 2

Response-time metrics (a)–(d) (PROTOCOL_FREEZE.md, section 6) are computed separately into `outputs/paper3_baseline/` for paper 3.

