# Paper 2 — final results summary (frozen protocol)

Generated 2026-10-20 by `scripts/make_export.py --final`. Every number below is computed from the CSV files shipped in this export (`results/`, `stats/`, `paper_tables/`).

## Scope

- Paper 2 covers PhD research objective 1 only: "To design AI-based intelligent model to enhance attack detection accuracy and reduce false alarms in Security Information and Event Management System".
- **Response-time metrics** (per-episode time to detect, episode detection rate, benign alerts per hour, per-flow inference latency) were **pre-specified in `PROTOCOL_FREEZE.md` (section 6) before any result was seen, and are reported in a companion paper (paper 3)**. They are not reported in paper 2. Metrics (a)–(c) were computed from the saved per-flow predictions into `outputs/paper3_baseline/`; latency is measured in paper 3.
- Per-flow validation and test predictions for every run and seed are kept permanently in `outputs/paper2_final/predictions/` (not shipped here, about 1 GB).
- Main sources: ToN-IoT and CSE-CIC-IDS2018 from BigFlow-NIDS v2. BoT-IoT and BigFlow's UNSW-NB15 part are limitations only. External: original UNSW-NB15 (full protocol), CIC-IoT2023 (random split only).

## Run

- Protocol frozen in `PROTOCOL_FREEZE.md`; corrections after the freeze are listed in its section 9. Test families declared in `reports/stats_protocol.md` before any statistic was computed.
- Run: option (b-ii), launched from commit e800706 on 2026-10-16, finished 2026-10-19; meta of the main context run records commit 601f92f, scikit-learn 1.9.0, torch 2.13.0+cu130, Python 3.12.3.
- Completeness verified: `reports/phase_a_completeness.md`, `reports/phase_b_completeness.md`.
- Metric: design-weighted TPR at 1% FPR (threshold = 99th percentile of validation benign scores), shown with the FPR reached on test. Subset (i) = families testable on unseen episodes (primary); (ii) = single-episode families tested within their episode; (iii) = all test attacks.

## What survives (frozen protocol)

**(a) Pooled rates mostly reflect test composition** (Tables 2a/2b, Figures 2 and 6). HistGB on flow features, 30 seeds: CSE-CIC-IDS2018 (iii) 0.933 [0.929, 0.937], (i) 0.543 [0.455, 0.637], (ii) 1.000 [1.000, 1.000]; FPR reached 0.011 mean / 0.018 worst seed. ToN-IoT (iii) 0.652 [0.578, 0.723], (i) 0.629 [0.571, 0.689]; FPR 0.020 mean / 0.073 worst seed. On CSE-CIC the overall rate is dominated by single-episode families tested within their own episode; Figure 6 shows its seeds falling into clusters by which Infiltration episodes reach test.

**(b) Thresholds do not hold on test** (Table 3, Figure 3). ToN-IoT, target 1%: flow 0.020 mean / 0.073 worst seed; flow + host 0.025 mean / 0.259 worst seed; flow + neighbourhood + host 0.036 mean / 0.322 worst seed; family-gated (split validation) 0.030 mean / 0.287 worst seed.

**(c) Context-feature gains were partly leakage** (Tables 5, 6, Figure 4). Subset (i), HistGB, 30 seeds: k-NN neighbourhood on CSE-CIC -0.007 [-0.009, -0.004], Holm p < 0.001; host on CSE-CIC +0.160 [+0.112, +0.203], Holm p < 0.001; host on ToN-IoT -0.172 [-0.242, -0.106], Holm p < 0.001.

**(d) ToN-IoT drift** (Table A7, Figure 5). Chronological split vs main protocol, (iii): HistGB flow 0.168 [0.141, 0.195]; difference -0.453 [-0.600, -0.296], Holm p = 0.006.

**(e) Few episodes, wide uncertainty** (Table A10, Figure 6).

| source | seeds | TPR (i), seed-bootstrap CI | test episodes per seed (median) | episode-bootstrap CI within a seed (median bounds) | FPR reached |
|---|---|---|---|---|---|
| ToN-IoT | 30 | 0.629 [0.571, 0.689] | 37 | [0.168, 0.989] | 0.020 ± 0.023 / 0.073 |
| CSE-CIC-IDS2018 | 30 | 0.543 [0.455, 0.637] | 30 | [0.564, 0.994] | 0.011 ± 0.003 / 0.018 |

## Exploratory analyses (post-hoc, labelled as deviations)

Not pre-specified; reported as exploratory (Tables S1–S4).

S1 — same families under the random split (no detectable penalty for unseen episodes at this number of episodes):

| source | episode split (i) | random rows, same families | random rows, same families, episode-split family mix | unseen-episode effect at equal mix |
|---|---|---|---|---|
| CSE-CIC-IDS2018 | 0.515 [0.391, 0.651] | 0.774 [0.747, 0.825] | 0.457 [0.393, 0.578] | -0.058 [-0.139, +0.028] |
| ToN-IoT | 0.600 [0.507, 0.698] | 0.745 [0.743, 0.749] | 0.591 [0.569, 0.625] | -0.008 [-0.103, +0.077] |

S4 — benign-identical flows removed from subset (i) (duplicates do not explain the subset (i) rates):

| source | features | seeds | TPR (i), all attack flows | TPR (i), benign-identical flows removed | change | share of (i) weight removed | FPR reached |
|---|---|---|---|---|---|---|---|
| CSE-CIC-IDS2018 | flow | 10 | 0.515 [0.391, 0.651] | 0.533 [0.458, 0.647] | +0.019 [-0.034, +0.073] | 0.7460 | 0.011 ± 0.002 / 0.016 |
| CSE-CIC-IDS2018 | flow + host | 10 | 0.703 [0.638, 0.769] | 0.723 [0.675, 0.790] | +0.020 [-0.016, +0.056] | 0.7460 | 0.011 ± 0.002 / 0.015 |
| ToN-IoT | flow | 10 | 0.600 [0.507, 0.698] | 0.681 [0.586, 0.763] | +0.082 [+0.032, +0.129] | 0.8280 | 0.019 ± 0.026 / 0.066 |
| ToN-IoT | flow + host | 10 | 0.409 [0.252, 0.569] | 0.371 [0.175, 0.594] | -0.038 [-0.127, +0.053] | 0.8280 | 0.011 ± 0.017 / 0.050 |

S2 (split-gap decomposition, both orders and average) and S3 (tied thresholds, score ≥ τ) are in `paper_tables/exploratory/`.

## Reporting rules used throughout

- Every TPR at 1% FPR is shown with the FPR reached on test; every pooled subset value has a per-family table.
- Cells whose threshold equals the maximum score read "cannot operate at 1% FPR (tied scores)".
- The family-gated detector is reported as a safe default; it does not match the best single feature set under split validation.

## Contents

- `PROTOCOL_FREEZE.md`, `reports/` (stats protocol, phase-1 summary, completeness checks, post-hoc reports, runtime tables, endpoint selection)
- `paper_tables/` (main Tables 1–7, supplement A1–A13, exploratory S1–S4; CSV + LaTeX + README preview)
- `figures/` (Figures 1–6, PDF + PNG)
- `stats/` (all tests, descriptive tables, per-family TPR, post-hoc CSVs)
- `results/` (per-seed metric rows of every final run), `logs/` (run logs and per-run meta with commit, versions and wall-clock time)
- `paper/` (outline, related work), `scripts/` (driver, statistics, tables, figures, launch script)
