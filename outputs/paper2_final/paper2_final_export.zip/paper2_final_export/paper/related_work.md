# Related work and novelty check

Literature search done on 2026-10-08 with web search; updated 2026-10-21 for the final run (section 5,
stale numbers replaced with recomputed values). Abstracts and full texts were read
where accessible. **Before submission, read every paper marked "key" in full and repeat the
search in Google Scholar / IEEE Xplore / ACM DL** — web search does not cover paywalled
venues fully, and work published after this date is not covered.

---

## 1. Must-fix issues found during the search

### 1.1 The local BigFlow copy was incomplete — ✅ resolved 2026-10-09
- Official release: **BigFlow-NIDS**, M. B. Uddin, M. S. Arefin, Mendeley Data **v2**,
  DOI 10.17632/nv729tbdgz.2, 22 Jan 2026, CC BY 4.0. **66,935,021 flows, 67 Parquet files,
  55 attributes, 32 attack categories.** (Another page states 34 categories and 2 Jan 2026;
  check which is right.)
- Earlier local copy: **46 files,
  46,000,000 flows**; `merged_part_6`–`9` and everything from `merged_part_50` onwards are
  missing.
- **Resolved:** the complete release (67 files, 66,935,021 flows, verified) is now at
  `data/raw/BigFlow-NIDS-V2-Merged-Parquet` (path set in `configs/config.yaml`). All
  experiments are being re-run with `scripts/run_full_pipeline.sh`; the 46M-subset results
  are archived in `outputs/archive_46M_subset/`.

### 1.2 BigFlow merges NetFlow **v3**, not v2
- Sources: NF-UNSW-NB15-v3, NF-ToN-IoT-v3, NF-BoT-IoT-v3, NF-CSE-CIC-IDS2018-v3
  (53 NetFlow features + label + attack = 55 columns, matching the local files).
- The release states that the Spark pipeline **deduplicated** flows. That is consistent with
  our finding: exact *rows* are unique, but **behaviour vectors** (after removing
  timestamps, IPs, source port) are heavily duplicated. Say this explicitly in the paper.

---

## 2. Closest prior work

| Work | What it does | Overlap with our findings | Status |
|---|---|---|---|
| **Zhao & Hassan, "A First-Principles Evaluation of Graph-Based Network Intrusion Detection Systems", ACM CCS 2026** (arXiv 2609.12263; title, authors, venue and threshold findings verified 2026-10-21, see §2b) — **key** | Re-implements 5 unsupervised graph IDS (Argus, Euler, Pikachu, VGRNN, Anomal-E) on Campus, LANL, OpTC, corrected CIC-IDS-2017; 9 evaluation gaps (window choice, threshold instability, transductive thresholding, preprocessing contract, …); temporal-order splits; simple GIDS-Lite baseline often ranks first | Finding 4 in spirit: "architectural complexity is not a consistent driver of detection quality". Our E-GraphSAGE result (never beats flow-only gradient boosting on ToN-IoT) agrees. | **Complementary.** No E-GraphSAGE / supervised edge classification, no NetFlow benchmarks, no merged datasets, no source shortcut, no duplicate/label-ambiguity analysis, no tree models with host features, no fixed-FPR reporting in main results. |
| **Arp et al., "Dos and Don'ts of ML in Computer Security", USENIX Security 2022** — **key** | 10 pitfalls incl. sampling bias, spurious correlations, data snooping (test, temporal, selective) | Findings 1 and 3 are instances of spurious correlations and temporal snooping. | Frame our work as a **quantified, dataset-specific case study** of these pitfalls; do not claim the concepts are new. |
| **Sarhan, Layeghy, Portmann et al.** — NetFlow datasets (arXiv 2011.09144), standard feature set / v2 (arXiv 2101.11315), NF-UQ-NIDS merged dataset | Creates NF-* datasets and the merged NF-UQ-NIDS (75.99M records), which carries a column naming each flow's source dataset | Merged NetFlow benchmarks exist and their source is known. | **No analysis found** of source identifiability as a shortcut. Our finding 1 appears new; confirm with a deeper search. |
| **Luay et al., "Temporal Analysis of NetFlow Datasets for NIDS"** (arXiv 2503.04404) | Introduces the v3 temporal features; time-series analysis of attacks | Same data generation (v3). | No leakage, splitting or duplicate analysis in the abstract. Cite as the v3 source. |
| **Layeghy et al., "On Generalisability of ML-based NIDS"** (arXiv 2205.04112) | Cross-dataset generalisation on NetFlow datasets | Related to per-source evaluation and future cross-dataset work. | Cite in discussion. |
| **Raskovalov et al., "Investigation and rectification of NIDS datasets …"** (arXiv 2212.13994) | Finds inconsistencies between ToN-IoT versions; builds ToN-IoT-R; E-GraphSAGE with modified node initialisation | ToN-IoT quality and E-GraphSAGE. | Shows ToN-IoT has known issues, but **does not quantify benign/attack duplicate ambiguity**. Our finding 2 (56.0% / 93.9% scanning) appears new; read the full paper to confirm. |
| **Engelen, Rimmer, Joosen, "Troubleshooting an Intrusion Detection Dataset: the CICIDS2017 Case Study"**, IEEE S&P Workshops 2021; **Liu, Engelen, Lynar, Essam, Joosen, "Error Prevalence in NIDS datasets: A Case Study on CIC-IDS-2017 and CSE-CIC-IDS-2018"**, IEEE CNS 2022, pp. 254–263, DOI 10.1109/CNS56114.2022.9947235 (venue verified 2026-10-21) — **key** | Errors in attack orchestration, feature generation, documentation and labelling of both CIC datasets; a recreated dataset with corrected labelling logic | Our CSE-CIC-IDS2018 ambiguity (Infiltration 74.5%, XSS 90.8%, SQL injection 78.2% identical to benign) is consistent with known labelling problems. Subset (i) on CSE-CIC is 94% Infiltration by weight, but exact duplicates do not explain its low rate (S4). | Cite as context for known CIC dataset errors only. **Make no Infiltration-specific label-noise claim** (decision 2026-10-21): the abstract does not mention Infiltration and we have no direct evidence. |
| **Lanvin, Gimenez, Han, Majorczyk, Mé, Totel, "Errors in the CICIDS2017 dataset and the significant differences in detection performances it makes"**, CRiSIS 2022 (LNCS, 2023, pp. 18–33; HAL hal-03775466) | Labelling and capture errors in CICIDS2017 (misordered and duplicated packets, attacks performed but not labelled) and their effect on measured detection | Same message for the predecessor dataset: label errors change measured performance. | Cite with Engelen et al. and Liu et al. |
| **Youssef, "Stream Assembly Is an Uncontrolled Treatment in Streaming Intrusion-Detection Benchmarks"**, arXiv 2605.24696 (v1 23 May 2026 under the title CALIBURN; v3 14 Sep 2026, substantially corrected) | How the assembly of an evaluation stream from captures changes results: on CICIDS2017, reordering the same records gives test sets sharing 32.5% of records with different prevalence, reversing a ranking; on LITNET-2020, pooling captures yields an equal-weight average prevalence | Same theme as our composition finding (a): what is in the test set drives the number. | **Differs:** studies stream construction for streaming detectors on CICIDS2017 / LITNET-2020; we study a merged NetFlow-v3 benchmark, exact duplicates, full-data attack episodes and threshold transfer. Cite v3 (the CALIBURN versions were corrected). |
| **Goldschmidt & Chudá, "Network Intrusion Datasets: A Survey, Limitations, and Recommendations"**, Computers & Security 156 (2025) (arXiv 2502.06688) | Systematic review of 89 datasets, 13 properties, best practices | General dataset-quality context. | Survey only, no experiments on these benchmarks. |
| **El Mahdaouy et al., "Deep Learning for Contextualized NetFlow-Based NIDS"** (arXiv 2602.05594, 2026) | Survey; names temporal leakage, splitting problems, dataset flaws; argues context helps only "when attacks induce measurable temporal or relational structure" | Matches the framing of finding 4 (context helps on CIC-IDS2018, not ToN-IoT). | Survey, no experiments. Useful citation for motivation. |
| **E-GraphSAGE, Lo et al.** (arXiv 2103.16329, NOMS 2022) | Original graph IDS baseline | Our re-implementation. | No author-verified implementation found; our re-implementation must be described as such. |
| Research Square preprint rs-10400643 ("Edge Weight Concentration…") | NAT / perimeter aggregation breaks node-identity assumptions; window-grouped CV for graph-context features | Related to node identity and grouped splits. | Preprint; full text not accessible here. Read before submission. |

---

## 2b. Positioning the threshold-transfer finding against Zhao & Hassan (verified 2026-10-21)

Verified from the full text (arXiv 2609.12263 v1, 10 Sep 2026; accepted to ACM CCS 2026): Rui Zhao and Wajih
Ul Hassan, "A First-Principles Evaluation of Graph-Based Network Intrusion Detection Systems". They re-implement
five unsupervised graph IDS (Argus, Euler, Pikachu, VGRNN, Anomal-E) plus a control (GIDS-Lite) on Campus, LANL,
OpTC and a corrected CIC-IDS-2017, and name nine evaluation gaps. Two concern thresholds. EG2,
threshold-selection instability: thresholds drawn from a random validation sample change with the seed (e.g. a
70.4-point TPR range for Euler on Campus), and on LANL a validation split that is 12.5% malicious against 0.6% in
test means "a validation-calibrated threshold may not transfer". EG3, transductive thresholding: Pikachu picks
its threshold on the labelled test edges; an inductive threshold drops TPR by up to 83.6 points. They also report
recall at FPR budgets (e.g. 1% FPR: 94% on CI-2017, 0% on OpTC).

**Paragraph for the paper (draft):** Zhao and Hassan show for unsupervised graph IDS that thresholds chosen on a
random validation sample are unstable across seeds and that thresholds chosen on test data overstate
performance; they recommend deterministic, reported threshold selection. Our threshold-transfer finding shares
their premise (thresholds must come from validation data, and a validation-calibrated operating point need not
hold on test) and their recommendation, but differs in three ways. First, our thresholds are deterministic (the
99th percentile of all validation benign scores) and the test set is separated from validation by full-data
attack episodes, 30-minute benign blocks and an embargo, so the failure we measure is transfer between episodes
and time blocks, not sampling noise. Second, we report the false-positive rate the threshold actually reaches on
test, per source, protocol, model and feature set (Table 3, Figure 3), for supervised flow classifiers and
E-GraphSAGE on a merged NetFlow benchmark: a 1% target reaches 2.0% on average and 7.3% in the worst seed on
ToN-IoT, against 1.0–1.1% on CSE-CIC-IDS2018. Third, for gradient boosting, host-behaviour context makes the
transfer worse on ToN-IoT: the worst seed reaches 25.9% with host features, 32.2% with neighbourhood and host
features, and 28.7% for the family-gated detector, so a feature set chosen at a nominal 1% FPR can multiply the
alert volume a SIEM analyst actually sees. (Random forest and the MLP do not show this: with host features their
worst seeds reach 5.9% and 3.6%, but several of their seeds cannot operate at 1% FPR because of tied scores, which
also lowers the FPR reached.)

## 3. Novelty assessment per finding (final run, 2026-10-21)

| Finding | Concept known? | What looks new | Strength |
|---|---|---|---|
| Data audit: source shortcut (99.4% source identification; timestamp-only F1 0.85 pooled) | Spurious correlation / sampling bias (Arp et al.) | Quantified for a merged NetFlow benchmark | **Medium–high** |
| Data audit: exact-duplicate label ambiguity (ToN-IoT 56.0%, scanning 93.9%; irreducible error 4.2%) | Label errors known for CIC datasets (Engelen; Liu; Lanvin) | Quantified for ToN-IoT-v3 at full scale, with an irreducible-error bound | **Medium–high** (ToN-IoT), low (CSE-CIC) |
| (a) Pooled rates mostly reflect test composition (CSE-CIC 0.93 overall vs 0.54 on families testable on unseen episodes) | Test-set construction effects (Youssef 2026, streaming) | Full-data episode subsets with per-family design weights on a merged NetFlow benchmark | **Medium–high** |
| (b) Thresholds do not hold on test (ToN-IoT 1% target → 2.0% mean, 7.3% worst; 26–32% with host features) | Threshold instability is one of Zhao & Hassan's (CCS 2026) gaps for unsupervised GIDS | Supervised detectors at fixed FPR across attack episodes, with the reached FPR reported per feature set | **Medium** — position against CCS 2026 |
| (c) Context gains partly leakage (k-NN neighbourhood gain disappears once inductive; host features help CSE-CIC, hurt ToN-IoT; host beats E-GraphSAGE on CSE-CIC) | Transductive leakage in graph learning known in general | Quantified for NetFlow benchmarks with past-only host features and an inductive vs transductive E-GraphSAGE comparison | **Medium** |
| (d) ToN-IoT drift; (e) few episodes, wide uncertainty | Temporal snooping known | Episode-level bootstrap and per-family scope table | **Low–medium** (supporting) |
| Split inflation: ToN-IoT +8.1 to +8.6 F1 points (random vs episodes), CSE-CIC +1.4 to +1.7 | Temporal snooping well known | Post-hoc decomposition into family mix, threshold transfer and within-episode leakage | **Medium** — present as a protocol finding |

**Overall:** defensible as **"a leakage audit of a merged NetFlow-v3 benchmark (BigFlow-NIDS) under a frozen,
leakage-controlled protocol, showing that pooled rates mostly reflect test composition and that thresholds do
not transfer"**. Do not claim to have discovered temporal leakage, threshold instability or that graph IDS are
over-complex in general; position against Arp et al., Zhao & Hassan (CCS 2026) and Youssef (2026).

## 4. Searches still to do (author)
- Google Scholar: "BigFlow-NIDS" (papers using the dataset since Jan 2026).
- "NF-UQ-NIDS" + "dataset identification" / "shortcut" / "source label".
- "duplicate flows" + "NetFlow" / "ToN-IoT" + "label noise".
- Read the full texts of arXiv 2212.13994 and rs-10400643, and the 2022 CIC error-prevalence paper
  (Liu et al., DOI 10.1109/CNS56114.2022.9947235), in particular anything on Infiltration.
- Search for published analyses of the CSE-CIC-IDS2018 Infiltration labels specifically (none found by web
  search on 2026-10-21).

## Sources
- BigFlow-NIDS (Mendeley Data v2): https://data.mendeley.com/datasets/nv729tbdgz/2
- Zhao & Hassan, CCS 2026: https://arxiv.org/abs/2609.12263
- Arp et al., USENIX Security 2022: https://arxiv.org/abs/2010.09470
- NetFlow datasets for ML-based NIDS: https://arxiv.org/abs/2011.09144
- Towards a Standard Feature Set for NIDS Datasets: https://arxiv.org/abs/2101.11315
- Temporal Analysis of NetFlow Datasets (v3): https://arxiv.org/abs/2503.04404
- NetFlow v3 datasets page: https://staff.itee.uq.edu.au/marius/NIDS_datasets/
- On Generalisability of ML-based NIDS: https://arxiv.org/abs/2205.04112
- Investigation and rectification of NIDS datasets (ToN-IoT-R): https://arxiv.org/abs/2212.13994
- Error Prevalence in NIDS datasets (CIC-IDS-2017/2018): https://archive.cps-vo.org/node/97449 ; DOI https://doi.org/10.1109/cns56114.2022.9947235
- Errors in the CICIDS2017 dataset (Lanvin et al., CRiSIS 2022): https://hal.archives-ouvertes.fr/hal-03775466
- Stream assembly (Youssef, arXiv 2605.24696, formerly CALIBURN): https://arxiv.org/abs/2605.24696
- Network Intrusion Datasets survey (Computers & Security 2025): https://arxiv.org/abs/2502.06688
- Deep Learning for Contextualized NetFlow-Based NIDS (survey): https://arxiv.org/abs/2602.05594
- E-GraphSAGE: https://arxiv.org/abs/2103.16329
- Research Square preprint: https://www.researchsquare.com/article/rs-10400643/latest
